// Batch 5 is appended after the four preserved generators. No old timeline is rewritten.
module.exports=({root,ab,vm,machine,master,rig,el,id,group,vector,ellipse,glow,grad})=>{
 const copy=e=>JSON.parse(JSON.stringify(e));function*walk(e=root){yield e;for(const c of e.kids)yield*walk(c);}
 const find=n=>[...walk()].find(e=>e.a.name===n), inst=vm.kids.find(e=>e.t==='ViewModelInstance');
 const cond=(n,t,v,op='equal')=>el('TransitionViewModelCondition',{opValue:op},[el('TransitionPropertyViewModelComparator',{},[el('BindableProperty'+t,{},[el('DataBindContext',{sourcePathIds:'0:3-'+(n==='state'?'0:5':id('property_'+n)),propertyKey:{Trigger:686,Boolean:634,Number:636}[t]})])]),el('TransitionValue'+t+'Comparator',{value:v})]);
 const tr=(to,c=[],duration=300,extra={})=>el('StateTransition',{stateToId:to,duration,enableEarlyExit:true,...extra},c);
 const end=(to,ms=0)=>tr(to,[],ms,{enableExitTime:true,exitTimeIsPercetange:true,exitTime:100});
 function layer(n){const l=el('StateMachineLayer',{name:n,id:id('b5_layer_'+n)}),entry=el('EntryState'),any=el('AnyState');l.kids.push(any,el('ExitState'),entry);machine.kids.push(l);return {l,entry,any};}
 function anim(n,d,t,loop='oneShot'){const a=el('LinearAnimation',{name:n,id:id('b5_anim_'+n),duration:d,fps:60,loopValue:loop});ab.kids.push(a);for(const [n,props]of Object.entries(t)){const o=el('KeyedObject',{objectId:find(n)?.a.id??id(n)});a.kids.push(o);for(const [key,vals]of Object.entries(props))o.kids.push(el('KeyedProperty',{propertyKey:key},(Array.isArray(vals)?vals:[[0,vals]]).map(([frame,value])=>el(Number(key)===121?'KeyFrameId':'KeyFrameDouble',{frame,value,interpolationType:Number(key)===121?'hold':'linear'}))));}return a;}
 function state(l,a,n){const s=el('AnimationState',{id:id('b5_state_'+n),animationId:a.a.id,reset:true});l.kids.push(s);return s;}
 function base(n){const t={};for(const o of find(n).kids){if(o.t!=='KeyedObject')continue;const obj=[...walk()].find(e=>e.a.id===o.a.objectId);t[obj.a.name]={};for(const p of o.kids)t[obj.a.name][p.a.propertyKey]=Number(p.kids[0].a.value);}return t;}
 function wrap(child,n){const parent=[...walk()].find(e=>e.kids.includes(child)),w=el('Node',{name:n,id:id(n),exportName:true},[child]);w.p=parent.p;parent.kids[parent.kids.indexOf(child)]=w;return w;}
 const set=(t,n,k,v)=>{t[n]??={};t[n][k]=v;};
 function wave(t,n,k,b,a,d,cycles=1,phase=0){set(t,n,k,Array.from({length:25},(_,i)=>[Math.round(i*d/24),b+a*Math.sin(i*Math.PI*2*cycles/24+phase)]));}
 // Positive-scale directional poses: facial projection and independent appendage parallax.
 find('play_facing').kids=find('play_facing').kids.filter(e=>e.t!=='DataBindContext');
 const turnParts=['head','body','ear_left','ear_right','fin_left','fin_right','tail_rig','eye_left','eye_right','brow_left','brow_right','mouth','worried_mouth','closed_eyes','forehead_gem','antennae'];
 for(const n of turnParts)wrap(find(n),'turn_'+n);
 wrap(find('reaction_body'),'turn_hop');
 const neutral={};for(const n of turnParts)neutral['turn_'+n]={13:0,14:0,15:0,16:1,17:1,18:1};
 const left=copy(neutral);
 Object.assign(left.turn_head,{13:-14,15:-.07,16:.93});
 Object.assign(left.turn_body,{13:-6,15:.09,16:.9});
 Object.assign(left.turn_ear_left,{13:48,14:7,15:.19,16:.82});
 Object.assign(left.turn_ear_right,{13:-83,14:-13,15:-.24,16:.74,18:.88});
 Object.assign(left.turn_fin_left,{13:28,15:-.2,16:.75});Object.assign(left.turn_fin_right,{13:-48,15:.3});
 Object.assign(left.turn_tail_rig,{13:48,15:-.18,16:.88});
 // Local eye assemblies originate at the head pivot, hence paired shifts rather than a mirror.
 for(const n of ['eye_left','brow_left'])Object.assign(left['turn_'+n],{13:-30,14:10,16:.95});
 for(const n of ['eye_right','brow_right'])Object.assign(left['turn_'+n],{13:-65,14:-10,16:.8});
 for(const n of ['mouth','worried_mouth','closed_eyes'])Object.assign(left['turn_'+n],{13:-55,14:2,16:.93});
 Object.assign(left.turn_forehead_gem,{13:-70,16:.82});Object.assign(left.turn_antennae,{13:-36,15:-.08,16:.92});
 const tl=layer('Directional Turn'),rightState=state(tl.l,anim('_facing_right',1,neutral),'facing_right'),leftState=state(tl.l,anim('_facing_left',1,left),'facing_left');tl.entry.kids.push(tr(rightState.a.id,[],0));
 const turns={};
 for(const dir of [-1,1]){const from=dir<0?neutral:left,to=dir<0?left:neutral,t={};for(const [n,p]of Object.entries(from))for(const [k,v]of Object.entries(p)){const target=to[n][k];set(t,n,k,[[0,v],[5,v*.75+target*.25],[11,(v+target)/2],[16,v*.2+target*.8],[21,target]]);}
  // A narrow side profile, followed by the open front plane and opposite three-quarter pose.
  t.turn_head[16]=[[0,from.turn_head[16]],[5,.64],[11,1.04],[16,.72],[21,to.turn_head[16]]];
  t.turn_body[16]=[[0,from.turn_body[16]],[5,.78],[11,1.02],[16,.82],[21,to.turn_body[16]]];
  t.turn_eye_right[18]=[[0,1],[5,.08],[11,.9],[16,.2],[21,1]];
  t.turn_ear_left[15]=[[0,from.turn_ear_left[15]],[5,-.18*dir],[11,.08],[16,.14*dir],[21,to.turn_ear_left[15]]];
  t.turn_ear_right[15]=[[0,from.turn_ear_right[15]],[5,.30*dir],[11,-.08],[16,-.18*dir],[21,to.turn_ear_right[15]]];
  t.turn_tail_rig[15]=[[0,from.turn_tail_rig[15]],[7,.28*dir],[14,-.24*dir],[21,to.turn_tail_rig[15]]];
  turns[dir]=state(tl.l,anim(dir<0?'_turn_left':'_turn_right',21,t),'turn_'+dir);turns[dir].kids.push(end(dir<0?leftState.a.id:rightState.a.id));
 }
 rightState.kids.push(tr(turns[-1].a.id,[cond('facing','Number',0,'lessThan')],0));leftState.kids.push(tr(turns[1].a.id,[cond('facing','Number',0,'greaterThanOrEqual')],0));
 turns[-1].kids.unshift(tr(turns[1].a.id,[cond('facing','Number',0,'greaterThanOrEqual')],80));turns[1].kids.unshift(tr(turns[-1].a.id,[cond('facing','Number',0,'lessThan')],80));
 // Hop has its own state guard: sitting, lounging and walking keep their ground contact.
 const hopL=layer('Turn Hop'),hR=state(hopL.l,anim('_turn_hop_right_rest',1,{turn_hop:{14:0}}),'hop_r'),hL=state(hopL.l,anim('_turn_hop_left_rest',1,{turn_hop:{14:0}}),'hop_l');hopL.entry.kids.push(tr(hR.a.id,[],0));
 for(const [source,target,dir]of [[hR,hL,-1],[hL,hR,1]]){const hs=state(hopL.l,anim('_turn_hop_'+dir,21,{turn_hop:{14:[[0,0],[7,-10],[13,-12],[21,0]]}}),'hop_'+dir),c=()=>cond('facing','Number',0,dir<0?'lessThan':'greaterThanOrEqual');hs.kids.push(end(target.a.id));for(const s of [8,13,14])source.kids.push(tr(target.a.id,[c(),cond('state','Number',s)],0));source.kids.push(tr(hs.a.id,[c()],0));}
 // New state timelines reuse the original rig. Prior animations and state IDs remain intact.
 const walking={...base('idle'),...base('_activity_clear')};walking.float_control={13:560,14:914,15:.10,18:1};walking.orbit_front[18]=0;walking.orbit_back[18]=0;
 wave(walking,'float_control',14,914,6,72,2);wave(walking,'head',15,-.07,.025,72,2);wave(walking,'fin_left',15,-.55,.40,72,2);wave(walking,'fin_right',15,.6,.42,72,2,Math.PI);wave(walking,'tail_bone_0',15,1.30,.055,72);wave(walking,'tail_bone_1',15,.13,.14,72);wave(walking,'tail_bone_2',15,.1,.14,72,1,1);walking.eye_left[17]=.88;walking.eye_right[17]=.88;
 const travel={...base('idle'),...base('_activity_clear')};travel.float_control={13:560,14:610,15:.05,18:1};travel.orbit_front[18]=0;travel.orbit_back[18]=0;wave(travel,'float_control',14,610,9,120);wave(travel,'head',15,-.04,.015,120);wave(travel,'fin_left',15,-.16,.12,120);wave(travel,'fin_right',15,.23,.12,120,1,Math.PI);wave(travel,'tail_bone_0',15,1.88,.025,120);wave(travel,'tail_bone_1',15,.07,.08,120);wave(travel,'tail_bone_2',15,-.06,.08,120,1,1);
 const pet=find('Pet States'),old=pet.kids.filter(e=>e.t==='AnimationState'),ns=[state(pet,anim('walking',72,walking,'loop'),'walking'),state(pet,anim('floating_travel',120,travel,'loop'),'floating_travel')];
 const oldNames=['idle','sleeping','working_thinking','needs_attention','done_happy','idea','low_usage_worry','limit_reached','_lounging_settle','working_busy','confused','disconnected','chasing','sitting'];
 for(const s of old)ns.forEach((to,i)=>s.kids.push(tr(to.a.id,[cond('state','Number',14+i)],300)));
 const settle=copy(base('sitting'));settle.body[17]=[[0,1.16],[8,1.28],[18,1.25]];settle.head[14]=[[0,-69],[8,-81],[18,-77]];
 const stop=state(pet,anim('_walking_sit_settle',18,settle),'walking_sit_settle');stop.kids.push(end(old.find(s=>s.a.animationId===find('sitting').a.id).a.id,0));
 for(const [j,s]of [...ns,stop].entries()){oldNames.forEach((n,i)=>s.kids.push(tr(j===0&&i===13?stop.a.id:old.find(x=>x.a.animationId===find(n).a.id).a.id,[cond('state','Number',i)],300)));ns.forEach((to,i)=>{if(to!==s)s.kids.push(tr(to.a.id,[cond('state','Number',14+i)],300));});}
 // Walking uses a low compact silhouette. Held and full-body tricks retain priority.
 const ls=layer('Locomotion Scale'),l0=state(ls.l,anim('_locomotion_scale_clear',1,{}),'scale_clear'),l1=state(ls.l,anim('_walking_scale',1,{sitting_scale:{16:.52,17:.52},play_tail_visibility:{18:1},sitting_coiled_tail:{18:0},float_control:{13:560}}),'walking_scale');ls.entry.kids.push(tr(l0.a.id,[],0));l0.kids.push(tr(l1.a.id,[cond('state','Number',14),cond('held','Boolean',false)],300));l1.kids.push(tr(l0.a.id,[cond('state','Number',14,'notEqual')],300),tr(l0.a.id,[cond('held','Boolean',true)],240));machine.kids.splice(machine.kids.indexOf(ls.l),1);machine.kids.splice(machine.kids.indexOf(find('Held Pose')),0,ls.l);
 // Two transparent sentinels bracket every fox drawable. DrawRules move each original orb subtree.
 const rear=ellipse(master,'orbit_depth_back_anchor',0,0,.01,.01,'00000000'),front=ellipse(master,'orbit_depth_front_anchor',0,0,.01,.01,'00000000');master.kids.splice(master.kids.indexOf(rear),1);master.kids.unshift(rear);
 for(const n of ['session','weekly','fable']){const m=find(n+'_meter'),w=wrap(find(n+'_stats_visual'),n+'_depth_visual');const rules=el('DrawRules',{name:n+'_depth_order',id:id(n+'_depth_order'),drawTargetId:id(n+'_depth_front')},[el('DrawTarget',{name:n+'_depth_front',id:id(n+'_depth_front'),drawableId:front.a.id,placementValue:'before'}),el('DrawTarget',{name:n+'_depth_back',id:id(n+'_depth_back'),drawableId:rear.a.id,placementValue:'after'})]);m.kids.push(rules);}
 const orbitL=layer('Orbit Depth');
 function orbit(n,ground){const tracks={};for(const [i,m]of ['session','weekly','fable'].entries()){const p={13:[],14:[]},v={16:[],17:[],18:[]},order={121:[]};let last;for(let f=0;f<=1440;f+=12){const th=-2.45+i*2*Math.PI/3+f*Math.PI*2/1440,s=Math.sin(th),c=Math.cos(th),back=s<0;const depth=Math.max(0,-s);p[13].push([f,(ground?375:335)*c]);p[14].push([f,(ground?130:-110)+(ground?76:150)*s]);v[16].push([f,1-.15*depth]);v[17].push([f,1-.15*depth]);v[18].push([f,1-.30*depth]);if(back!==last){order[121].push([f,id(m+'_depth_'+(back?'back':'front'))]);last=back;}}tracks[m+'_meter']=p;tracks[m+'_depth_visual']=v;tracks[m+'_depth_order']=order;}return anim(n,1440,tracks,'loop');}
 const of=state(orbitL.l,orbit('_orbit_depth_floating',false),'orbit_floating'),og=state(orbitL.l,orbit('_orbit_depth_ground',true),'orbit_ground');orbitL.entry.kids.push(tr(of.a.id,[],0));for(const s of [13,14])of.kids.push(tr(og.a.id,[cond('state','Number',s),cond('held','Boolean',false)],360));og.kids.push(tr(of.a.id,[cond('state','Number',8,'notEqual'),cond('state','Number',13,'notEqual'),cond('state','Number',14,'notEqual')],360),tr(of.a.id,[cond('held','Boolean',true)],360));
 const loungeDepth=orbit('_orbit_depth_lounging',true);
 for(const [i,m]of ['session','weekly','fable'].entries()){const o=loungeDepth.kids.find(o=>o.a.objectId===find(m+'_meter').a.id);for(const p of o.kids)for(const k of p.kids){const th=-2.45+i*2*Math.PI/3+k.a.frame*Math.PI*2/1440,s=Math.sin(th);k.a.value=Number(p.a.propertyKey)===13?-380+70*Math.cos(th)+70*Math.max(0,s)+370*Math.max(0,-s):25-75*Math.cos(th)+160*Math.max(0,s)+130*Math.max(0,-s);}}
 loungeDepth.a.duration=2160;for(const e of walk(loungeDepth))if(e.a.frame!==undefined)e.a.frame*=1.5;
 const ol=state(orbitL.l,loungeDepth,'orbit_lounging');for(const s of [of,og])s.kids.unshift(tr(ol.a.id,[cond('state','Number',8),cond('held','Boolean',false)],360));for(const s of [13,14])ol.kids.push(tr(og.a.id,[cond('state','Number',s),cond('held','Boolean',false)],360));ol.kids.push(tr(of.a.id,[cond('state','Number',8,'notEqual'),cond('state','Number',13,'notEqual'),cond('state','Number',14,'notEqual')],360),tr(of.a.id,[cond('held','Boolean',true)],360));
 const offlineDepth=orbit('_orbit_depth_disconnected',false);for(const m of ['session','weekly','fable']){const o=offlineDepth.kids.find(o=>o.a.objectId===find(m+'_meter').a.id);for(const p of o.kids)for(const k of p.kids)k.a.value=Number(p.a.propertyKey)===13?k.a.value*240/335:-110+(k.a.value+110)*96/150;}
 const od=state(orbitL.l,offlineDepth,'orbit_disconnected');for(const s of [of,og,ol])s.kids.unshift(tr(od.a.id,[cond('state','Number',11),cond('held','Boolean',false)],360));od.kids.push(tr(ol.a.id,[cond('state','Number',8),cond('held','Boolean',false)],360));for(const s of [13,14])od.kids.push(tr(og.a.id,[cond('state','Number',s),cond('held','Boolean',false)],360));od.kids.push(tr(of.a.id,[cond('state','Number',11,'notEqual')],360),tr(of.a.id,[cond('held','Boolean',true)],360));
 // The existing land reaction retains its authored safe meter route while the body descends.
 machine.kids.splice(machine.kids.indexOf(orbitL.l),1);machine.kids.splice(machine.kids.indexOf(find('Play Full Body')),0,orbitL.l);
 // Stats merge travels above the pet and remains bright/upright during its existing animation.
 const stl=layer('Stats Depth'),st0=state(stl.l,anim('_stats_depth_clear',1,{}),'stats_clear'),st1=state(stl.l,anim('_stats_depth_front',1,Object.fromEntries(['session','weekly','fable'].flatMap(n=>[[n+'_depth_order',{121:id(n+'_depth_front')}],[n+'_depth_visual',{16:1,17:1,18:1}]]))),'stats_front');stl.entry.kids.push(tr(st0.a.id,[],0));st0.kids.push(tr(st1.a.id,[cond('statsOpen','Boolean',true)],0));st1.kids.push(tr(st0.a.id,[cond('statsOpen','Boolean',false)],400));
 // Roam reactions share the established interruptible fidget layer and its neutral return.
 const durations={sniff:120,lookBack:90,happyHop:60},fidgets=find('Fidgets'),any=fidgets.kids.find(e=>e.t==='AnyState'),rest=fidgets.kids.find(e=>e.a.animationId===find('_reaction_rest').a.id);
 for(const [n,d]of Object.entries(durations)){vm.kids.push(el('ViewModelPropertyTrigger',{name:n,id:id('property_'+n)}));inst.kids.push(el('ViewModelInstanceTrigger',{viewModelPropertyId:id('property_'+n),propertyValue:0}));const t=base('_reaction_rest');
  if(n==='sniff'){t.reaction_head[15]=[[0,0],[24,.12],[88,.12],[120,0]];wave(t,'reaction_head',14,0,3.5,d,4);t.reaction_ear_left[15]=[[0,0],[20,.10],[95,.1],[120,0]];wave(t,'reaction_body',17,1,.012,d,4);}
  if(n==='lookBack'){t.reaction_head[15]=[[0,0],[24,-.20],[62,-.20],[90,0]];t.reaction_head[13]=[[0,0],[24,-32],[62,-32],[90,0]];t.reaction_ear_right[15]=[[0,0],[22,-.2],[62,-.2],[90,0]];t.reaction_tail[15]=[[0,0],[24,.12],[62,.12],[90,0]];}
  if(n==='happyHop'){t.reaction_body[14]=[[0,0],[10,4],[25,-30],[40,-12],[49,3],[60,0]];t.reaction_body[17]=[[0,1],[10,.97],[25,1.02],[49,.97],[60,1]];for(const s of ['left','right'])t['reaction_eye_'+s][17]=[[0,1],[18,.15],[40,.15],[60,1]];t.reaction_fin_left[15]=[[0,0],[25,-.25],[60,0]];t.reaction_fin_right[15]=[[0,0],[25,.25],[60,0]];}
  const s=state(fidgets,anim(n,d,t),'roam_'+n);any.kids.push(tr(s.a.id,[cond(n,'Trigger',0)],100));s.kids.push(end(rest.a.id,180));
  for(const [l,a]of [['Activity Reactions','_activity_fx_rest'],['Play Reactions','_play_fx_rest'],['Play Full Body','_play_full_rest']]){const layer=find(l),reset=layer.kids.find(s=>s.a.animationId===find(a).a.id);layer.kids.find(e=>e.t==='AnyState').kids.push(tr(reset.a.id,[cond(n,'Trigger',0)],180));}
 }
 // A glance is opposite the direction of travel; reuse the fidget with a left-facing correction.
 wrap(find('turn_head'),'roam_look_back');
 const rl=layer('Roam Direction'),rr=state(rl.l,anim('_roam_direction_clear',1,{roam_look_back:{13:0,15:0}}),'roam_direction_clear');rl.entry.kids.push(tr(rr.a.id,[],0));
 const rleft=state(rl.l,anim('_lookBack_left_projection',90,{roam_look_back:{13:[[0,0],[24,64],[62,64],[90,0]],15:[[0,0],[24,.4],[62,.4],[90,0]]}}),'look_back_left');
 rl.any.kids.push(tr(rleft.a.id,[cond('lookBack','Trigger',0),cond('facing','Number',0,'lessThan')],100));rleft.kids.push(end(rr.a.id,180));
 for(const p of vm.kids.filter(e=>e.t==='ViewModelPropertyTrigger'&&e.a.name!=='lookBack'))rl.any.kids.push(tr(rr.a.id,[cond(p.a.name,'Trigger',0)],180));
 // The horizontal lounging tail sweeps along its support plane, never below the artboard.
 const gl=layer('Grounded Tail Turn'),go=state(gl.l,anim('_ground_tail_clear',1,{}),'ground_tail_clear');gl.entry.kids.push(tr(go.a.id,[],0));
 const gr=state(gl.l,anim('_ground_tail_right',1,{turn_tail_rig:{13:0,15:0,16:1}}),'ground_tail_right'),gle=state(gl.l,anim('_ground_tail_left',1,{turn_tail_rig:{13:0,15:0,16:1}}),'ground_tail_left');
 for(const [s,dir]of [[gr,1],[gle,-1]]){go.kids.push(tr(s.a.id,[cond('state','Number',8),cond('held','Boolean',false),cond('facing','Number',0,dir<0?'lessThan':'greaterThanOrEqual')],300));s.kids.push(tr(go.a.id,[cond('state','Number',8,'notEqual')],300),tr(go.a.id,[cond('held','Boolean',true)],240));}
 for(const [from,to,dir]of [[gr,gle,-1],[gle,gr,1]]){const swing=state(gl.l,anim('_ground_tail_sweep_'+dir,21,{turn_tail_rig:{13:[[0,0],[7,-14],[14,-6],[21,0]],15:[[0,0],[7,.10],[14,.04],[21,0]],16:1}}),'ground_tail_sweep_'+dir);from.kids.unshift(tr(swing.a.id,[cond('facing','Number',0,dir<0?'lessThan':'greaterThanOrEqual')],0));swing.kids.push(end(to.a.id));}
 require('fs').writeFileSync('work/batch5-meta.json',JSON.stringify({durations,turnFrames:21,walkingFrames:72,travelFrames:120},null,2));
};





