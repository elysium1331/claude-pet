module.exports=({root,ab,vm,machine,master,rig,el,id,node,group,vector,ellipse,glow,paint,grad})=>{
  const instance=vm.kids.find(x=>x.t==='ViewModelInstance');
  for(const name of ['session','weekly','fable','lightBackdrop']){
    const type=name==='lightBackdrop'?'Boolean':'Number';
    vm.kids.push(el('ViewModelProperty'+type,{id:id('property_'+name),name}));
    instance.kids.push(el('ViewModelInstance'+type,{viewModelPropertyId:id('property_'+name),propertyValue:type==='Number'?0:false}));
  }
  function bind(target,name,key,converter){target.kids.push(el('DataBindContext',{sourcePathIds:'0:3-'+id('property_'+name),propertyKey:key,...(converter?{converterId:id(converter)}:{})}));}
  function mapper(name,minInput,maxInput,minOutput,maxOutput){root.kids.push(el('DataConverterRangeMapper',{id:id(name),name,minInput,maxInput,minOutput,maxOutput,clampLower:true,clampUpper:true}));}
  mapper('usage_fraction',0,100,0,1);mapper('usage_luminance',0,100,.12,.8);
  for(const level of [70,90]){
    mapper('threshold_range_'+level,0,level,0,1);
    root.kids.push(el('DataConverterOperationValue',{id:id('floor_'+level),name:'floor_'+level,operationType:'floor'}));
    root.kids.push(el('DataConverterGroup',{id:id('threshold_'+level),name:'threshold_'+level},[
      el('DataConverterGroupItem',{converterId:id('threshold_range_'+level)}),
      el('DataConverterGroupItem',{converterId:id('floor_'+level)})]));
  }
  // Add outlines below their existing silhouettes; copied geometry follows the same rig.
  const silhouettes=new Set(['head silhouette','left ear outer','right ear outer','left ear lobe','right ear lobe','body tapered silk','left fin','right fin','tail main ribbon']);
  function shadows(parent){const next=[];for(const obj of parent.kids){if(obj.t==='Shape'&&silhouettes.has(obj.a.name)){
    const name=obj.a.name+' legibility';const under=el('Shape',{...obj.a,id:id(name),name,y:Number(obj.a.y||0)+1.5});
    under.kids=obj.kids.filter(k=>['PointsPath','Ellipse'].includes(k.t)).map(k=>JSON.parse(JSON.stringify(k)));
    function rename(k){if(k.a.id)k.a.id=id(name+' clone '+k.a.id);for(const c of k.kids)rename(c);}under.kids.forEach(rename);
    const soft=paint(under,'Stroke','40152650',{name:'Default deep-blue shadow',thickness:9,cap:'round',join:'round'});soft.kids.push(el('Feather',{strength:12}));
    const strong=paint(under,'Stroke','78162952',{name:'Light backdrop shadow',thickness:13,cap:'round',join:'round',isVisible:false});strong.kids.push(el('Feather',{strength:16}));bind(strong,'lightBackdrop',41);
    const rim=paint(under,'Stroke','781C3154',{name:'Default dark rim',thickness:3,cap:'round',join:'round'});
    const rimStrong=paint(under,'Stroke','A01A3056',{name:'Light backdrop rim',thickness:3.4,cap:'round',join:'round',isVisible:false});bind(rimStrong,'lightBackdrop',41);
    next.push(under);
  }shadows(obj);next.push(obj);}parent.kids=next;}shadows(rig);
  // Replace three pearl assemblies, leaving the fourth orbital pearl and other stars intact.
  const replaced=new Set(['orbit pearl left','orbit pearl right','orbit lower pearl']);
  function removePearls(e){e.kids=e.kids.filter(k=>!replaced.has(k.a.name)&&!([...replaced].some(n=>k.a.name===n+' glow')));e.kids.forEach(removePearls);}removePearls(rig);
  // This assembly is a sibling of float_control: tired-state dimming cannot hide the meters.
  const meters=group('usage_meters',[560,930],master,[0,0]);
  const duration=1440; // 24 seconds, independent of state animations and one-shot holds.
  const animation=el('LinearAnimation',{id:id('usage_orbit_animation'),name:'usage_orbit',fps:60,duration,loopValue:'loop'});ab.kids.push(animation);
  const layer=el('StateMachineLayer',{name:'Usage Orbit',id:id('usage_orbit_layer')});machine.kids.push(layer);
  layer.kids.push(el('AnyState',{x:0,y:-160}),el('ExitState',{x:220,y:-160}),el('EntryState',{x:0,y:0},[el('StateTransition',{stateToId:id('usage_orbit_state')})]),el('AnimationState',{id:id('usage_orbit_state'),animationId:id('usage_orbit_animation'),x:240,y:0,reset:true}));
  ['session','weekly','fable'].forEach((name,index)=>{
    const phase=-2.45+index*2*Math.PI/3;
    const g=group(name+'_meter',[560,930],meters,[560,930],{exportName:true,scaleX:2.5,scaleY:2.5});
    // Local coordinates are used so marks stay upright as the orb travels.
    g.p=[0,0];g.a.x=0;g.a.y=0;
    const aura=glow(g,name+' aura',0,0,49,'82BFFF','28');
    const shell=ellipse(g,name+' shell',0,0,31,31,grad('RadialGradient',[-10,-12,32,0],[[0,'DB2B4265'],[.78,'DD172847'],[1,'ED345070']]),'BB7197BC',1.5);
    ellipse(g,name+' track',0,0,27,27,null,'884E6C91',7);
    const circle='M 0 -27 C 14.9117 -27 27 -14.9117 27 0 C 27 14.9117 14.9117 27 0 27 C -14.9117 27 -27 14.9117 -27 0 C -27 -14.9117 -14.9117 -27 0 -27 Z';
    [['calm','B7E7FF',null],['amber','FFD08B','threshold_70'],['high','FF997C','threshold_90']].forEach(([band,c,threshold])=>{
      const b=group(name+'_'+band,[0,0],g,[0,0],{opacity:threshold?0:1,exportName:true});if(threshold)bind(b,name,18,threshold);
      const core=ellipse(b,name+' '+band+' core',0,0,20,20,grad('RadialGradient',[-5,-7,22,0],[[0,'70'+c],[1,'00'+c]]));bind(core,name,18,'usage_luminance');
      const ring=vector(b,name+' '+band+' ring',circle,null,'FF'+c,7);
      const stroke=ring.kids.find(x=>x.t==='Stroke');stroke.a.cap='butt';
      const trim=el('TrimPath',{id:id(name+'_'+band+'_trim'),name:name+' '+band+' fill',start:0,end:0,modeValue:'sequential'});stroke.kids.push(trim);bind(trim,name,115,'usage_fraction');
    });
    for(let j=0;j<=index;j++)ellipse(g,name+' identity dot '+(j+1),(j-index/2)*9,0,2.8,2.8,'FFE5EDF6');
    vector(g,name+' gloss','M -19 -16 C -12 -24 -2 -27 10 -24',null,'667DA8CE',1.5);
    const ko=el('KeyedObject',{objectId:g.a.id});animation.kids.push(ko);
    for(const [key,axis] of [[13,0],[14,1]]){const kp=el('KeyedProperty',{propertyKey:key});ko.kids.push(kp);for(let f=0;f<=duration;f+=24){const theta=2*Math.PI*f/duration+phase;const x=335*Math.cos(theta),y=100*Math.sin(theta);kp.kids.push(el('KeyFrameDouble',{frame:f,value:+(axis===0?x:y).toFixed(5),interpolationType:'linear'}));}}
  });
};
