const fs = require('fs');
const path = require('path');
const out=path.join(__dirname,'pet'); fs.mkdirSync(out,{recursive:true});
let seq=100; const ids={};
function el(t,a={},kids=[]){return {t,a,kids};}
function id(n){return ids[n]??(ids[n]=`0:${seq++}`);}
function node(n,x,y,parent=[0,0],extra={}){return el('Node',{name:n,id:id(n),x:x-parent[0],y:y-parent[1],...extra});}
const root=el('Rive',{version:1,kind:'fragment'});
const ab=el('Artboard',{name:'CelestialFox',id:'0:1',width:560,height:600,defaultStateMachineId:'0:2',viewModelId:'0:3',viewModelInstanceId:'0:4',styleId:'0:6',includeInExport:true,exportName:true});root.kids.push(ab);
ab.kids.push(el('LayoutComponentStyle',{id:'0:6',name:'Artboard Style'}));
const master=node('pet_root',0,-20,[0,0],{scaleX:.5,scaleY:.5});ab.kids.push(master);
const rig=node('float_control',560,600);master.kids.push(rig);
function group(n,p,parent=rig,pp=[560,600],extra={}){const g=node(n,...p,pp,extra);g.p=p; parent.kids.push(g);return g;}
// Build in painter order, then reverse drawable siblings when serializing RML.
function color(c){return c.length===6?'FF'+c:c;}
function grad(type,xy,stops){return {type,xy,stops};}
const silk=grad('LinearGradient',[200,170,740,720],[[0,'8AABC9FF'],[.27,'C0577BE4'],[.48,'847D94D8'],[.72,'DDFBD3CB'],[1,'FFFFE9AC']]);
const peach=grad('LinearGradient',[300,260,620,680],[[0,'FFFDECCC'],[.28,'D7FFC9AB'],[.6,'6173D9FF'],[1,'E8FFFFDB']]);
function paint(parent,type,v,attrs={}){const p=el(type,{name:type,...attrs});parent.kids.push(p); if(typeof v==='string')p.kids.push(el('SolidColor',{colorValue:color(v)}));else {const g=el(v.type,{startX:v.xy[0],startY:v.xy[1],endX:v.xy[2],endY:v.xy[3]}); v.stops.forEach(([position,c])=>g.kids.push(el('GradientStop',{position,colorValue:color(c)})));p.kids.push(g);}return p;}
function parse(d){const tok=d.match(/[MLCZ]|-?\d*\.?\d+/g);let i=0,pts=[],closed=false;while(i<tok.length){let c=tok[i++];if(c==='M'||c==='L'){pts.push({p:[+tok[i++],+tok[i++]]});}else if(c==='C'){let c1=[+tok[i++],+tok[i++]],c2=[+tok[i++],+tok[i++]],p=[+tok[i++],+tok[i++]];pts[pts.length-1].out=c1;pts.push({p,in:c2});}else if(c==='Z'){closed=true;}else throw Error(c);}
if(closed&&pts.length>1&&pts[0].p.toString()===pts.at(-1).p.toString()){pts[0].in=pts.pop().in;} return {pts,closed};}
function vector(parent,n,d,fill,stroke=null,width=1.6,skin=false){if((d.match(/M/g)||[]).length>1){let result;d.split(/(?=M)/).filter(x=>x.trim()).forEach((part,i)=>{result=vector(parent,n+' '+i,part,fill,stroke,width,skin);});return result;}const p=parent.p??[0,0];const shape=el('Shape',{name:n,id:id(n),x:skin?0:-p[0],y:skin?0:-p[1]});parent.kids.push(shape);const {pts,closed}=parse(d);const geom=el('PointsPath',{name:n+'_path',isClosed:closed,isClockwise:true});shape.kids.push(geom);
const origin=skin?p:[0,0];
function weights(y){const t=Math.max(0,Math.min(2,(y-650)/160)),a=Math.floor(t),b=Math.min(2,a+1),w=Math.round((t-a)*255);return {indices:(a+1)|((b+1)<<8),values:(255-w)|(w<<8)};}
for(const q of pts){const a={x:q.p[0]-origin[0],y:q.p[1]-origin[1]};for(const h of ['in','out']){const c=q[h]??q.p;const dx=c[0]-q.p[0],dy=c[1]-q.p[1];a[h+'Rotation']=Math.atan2(dy,dx);a[h+'Distance']=Math.hypot(dx,dy);}const v=el('CubicDetachedVertex',a);geom.kids.push(v);if(skin){const w=weights(q.p[1]),wi=weights((q.in??q.p)[1]),wo=weights((q.out??q.p)[1]);v.kids.push(el('CubicWeight',{...w,inIndices:wi.indices,inValues:wi.values,outIndices:wo.indices,outValues:wo.values}));}}
if(skin){const s=el('Skin',{name:'Ribbon Skin'});for(let i=0;i<3;i++)s.kids.push(el('Tendon',{name:'Tail bind '+i,boneId:id('tail_bone_'+i),xx:0,xy:1,yx:-1,yy:0,tx:0,ty:i*160}));geom.kids.push(s);}
function adjusted(v){if(typeof v==='string'||!skin)return v;return {...v,xy:v.xy.map((z,i)=>z-origin[i%2])};}
if(fill)paint(shape,'Fill',adjusted(fill));if(stroke){if(['head silhouette','left ear outer','right ear outer','tail main ribbon','body tapered silk','left eye light','right eye light','check icon','lightbulb base'].includes(n)){const p=paint(shape,'Stroke',n.includes('eye')?'B0FFE09E':'80ACDFFF',{thickness:5,cap:'round',join:'round'});p.kids.push(el('Feather',{strength:7}));}paint(shape,'Stroke',adjusted(stroke),{thickness:width,cap:'round',join:'round'});}return shape;}
function ellipse(parent,n,x,y,rx,ry,fill,stroke=null,width=1.5){const p=parent.p??[0,0],s=el('Shape',{name:n,id:id(n),x:x-p[0],y:y-p[1]});parent.kids.push(s);s.kids.push(el('Ellipse',{name:'Path',width:rx*2,height:ry*2,originX:.5,originY:.5}));if(fill)paint(s,'Fill',fill);if(stroke)paint(s,'Stroke',stroke,{thickness:width});return s;}
function glow(parent,n,x,y,r,c='FFD391',alpha='66'){return ellipse(parent,n,x,y,r,r,grad('RadialGradient',[0,0,r,0],[[0,alpha+c],[.25,'33'+c],[1,'00'+c]]));}
function orb(parent,n,x,y,r=9){glow(parent,n+' glow',x,y,r*3,'FFC782','42');ellipse(parent,n,x,y,r,r,grad('RadialGradient',[-r*.3,-r*.4,r,0],[[0,'FFFFFCE1'],[.36,'FFFFE1A3'],[.75,'AAEAAF86'],[1,'00FFCF94']]),'DFFFF0C6',1.5);}
// Orbit is split so the foreground arc can pass in front of the floating body.
const orbitBack=group('orbit_back',[560,600]);
vector(orbitBack,'rear orbital thread','M 141 606 C 90 532 180 480 315 467 C 572 430 876 498 961 574',null,grad('LinearGradient',[140,500,960,620],[[0,'007BCCFF'],[.4,'779FCDFF'],[1,'44FFE1A9']]),2);
orb(orbitBack,'orbit pearl left',254,475,16);orb(orbitBack,'orbit pearl right',904,560,8);
// Tail: three actual bones deform all ribbon paths and their Bezier handles.
const tail=group('tail_rig',[450,650]);
const b0=el('RootBone',{name:'tail_bone_0',id:id('tail_bone_0'),length:160,rotation:Math.PI/2});
const b1=el('Bone',{name:'tail_bone_1',id:id('tail_bone_1'),length:160});const b2=el('Bone',{name:'tail_bone_2',id:id('tail_bone_2'),length:160});b1.kids.push(b2);b0.kids.push(b1);tail.kids.push(b0);
const tailFill=grad('LinearGradient',[390,650,655,1110],[[0,'348CF5FF'],[.2,'BD7695FF'],[.46,'AA99CFFF'],[.67,'CCAB9DEF'],[.83,'C7FFC4C3'],[1,'FFFFEAB2']]);
vector(tail,'tail main ribbon','M 475 615 C 431 752 403 798 488 870 C 543 920 661 898 707 986 C 747 1064 674 1139 644 1119 C 618 1100 670 1082 695 1084 C 685 1020 568 1038 508 1007 C 420 960 392 858 414 773 C 425 716 449 659 475 615 Z',tailFill,'BAC8F2FF',2,true);
vector(tail,'tail peach fold','M 475 615 C 395 814 419 912 577 957 C 649 977 719 1009 705 1072 C 689 1030 589 1033 545 1018 C 457 989 405 905 412 824 C 413 741 449 663 475 615 Z',grad('LinearGradient',[430,730,636,1058],[[0,'14FFFFE0'],[.5,'AAA9DCFF'],[.72,'FFFFE9C1'],[1,'94FFD5BD']]),null,1,true);
vector(tail,'tail silk light','M 454 683 C 418 782 415 874 508 922 C 589 965 690 934 735 979',null,'DFFFF0CB',2,true);
vector(tail,'tail blue spine','M 449 704 C 409 845 453 921 579 960 C 653 983 689 1011 694 1052',null,'BC99DFFF',2,true);
vector(tail,'tail filament left','M 471 637 C 415 707 324 845 363 870 C 391 904 364 791 414 730',null,grad('LinearGradient',[360,780,467,675],[[0,'EEFFE2A5'],[1,'087FCCFF']]),2,true);
vector(tail,'tail filament right','M 486 871 C 562 972 743 876 780 1007',null,'AFFFDDAD',2,true);
// Rear fins are separate controls with pivots at their attachment points.
const finL=group('fin_left',[493,598]);
vector(finL,'left fin','M 493 598 C 453 556 367 519 337 534 C 326 546 389 584 415 619 C 381 674 408 692 439 664 C 469 645 480 617 493 598 Z',silk,'9EC8E8FF',2);
vector(finL,'left fin vein','M 340 537 C 401 545 426 583 490 598 C 452 619 423 643 413 667',null,'B9FFE9C8',1.6);
const finR=group('fin_right',[660,641]);
vector(finR,'right fin','M 660 641 C 719 666 753 702 721 746 C 685 733 674 682 660 641 Z',silk,'9BCCEEFF',2);
vector(finR,'right fin light','M 663 645 C 705 682 715 714 721 741',null,'C4FFE6C0',2);
const body=group('body',[568,620]);
vector(body,'body tapered silk','M 489 571 C 508 610 614 620 688 589 C 666 698 621 749 565 823 C 547 830 491 731 478 679 C 466 630 472 602 489 571 Z',grad('LinearGradient',[482,599,599,826],[[0,'808CDAFF'],[.25,'C9FFDCC7'],[.6,'D2FFD6B5'],[.83,'EFFFEDC1'],[1,'FFFFF4C5']]),'E5FFE8C0',2.5);
vector(body,'chest core','M 497 602 C 548 641 633 641 677 606 C 655 645 602 665 572 702 C 548 663 523 638 497 602 Z',grad('LinearGradient',[552,614,573,701],[[0,'92FFFFEA'],[1,'FFFFFFD6']]),'CCFFFBE2',1.8);
vector(body,'body central filament','M 500 620 C 529 665 552 761 565 813 C 580 740 610 683 650 645',null,'B5FFF5D6',1.7);
vector(body,'body blue fold','M 488 610 C 481 682 532 763 558 798 C 507 719 536 670 488 610 Z','508CBFFF');
glow(body,'heart luminance',572,659,70,'FFF2B4','44');
// Head is a pivoted assembly; ears, antennae and expression controls follow it.
const head=group('head',[604,523]);
const earL=group('ear_left',[457,391],head,[604,523]);
vector(earL,'left ear outer','M 456 397 C 371 453 250 390 208 317 C 177 267 170 164 196 139 C 228 108 356 168 436 240 C 493 291 525 319 571 315 C 536 346 495 376 456 397 Z',grad('LinearGradient',[184,160,486,421],[[0,'C7C9D0E8'],[.27,'665E83D5'],[.52,'996891E5'],[.72,'B479BAFF'],[1,'DDFFD5BE']]),'BDE1EAFF',2.4);
vector(earL,'left ear warm membrane','M 197 140 C 261 125 303 209 326 267 C 365 370 431 349 565 317 C 477 386 375 382 338 323 C 301 265 294 178 197 140 Z',grad('LinearGradient',[225,156,464,350],[[0,'FFFFE8B6'],[.3,'FFFFDDBB'],[.55,'98FFD3C9'],[.8,'6E8CBAFF'],[1,'DBD3FFFF']]),'88FFF4D7',1);
vector(earL,'left ear blue seam','M 201 138 C 336 153 424 293 516 312',null,grad('LinearGradient',[214,140,510,319],[[0,'BAFFE7C1'],[.55,'FF94DCFF'],[1,'00B3FCFF']]),3);
vector(earL,'left ear lobe','M 440 369 C 363 358 303 393 303 437 C 307 488 390 481 443 437 C 467 417 477 389 440 369 Z',peach,'9FFFF0D6',1.8);
vector(earL,'left lobe light','M 327 451 C 358 436 382 383 439 374',null,'BFFFE9C3',2);
const earR=group('ear_right',[753,440],head,[604,523]);
vector(earR,'right ear outer','M 731 368 C 801 339 894 269 949 285 C 981 310 927 442 870 482 C 821 518 783 513 754 478 C 735 449 722 399 731 368 Z',grad('LinearGradient',[747,469,951,288],[[0,'B794E3FF'],[.25,'A46BA6FF'],[.5,'867190D9'],[.74,'CDBBAEDA'],[1,'FFFFE4C1']]),'ACB8E4FF',2.5);
vector(earR,'right ear warm membrane','M 743 391 C 840 409 879 310 949 287 C 910 312 897 385 857 424 C 815 466 775 452 743 391 Z',grad('LinearGradient',[945,289,779,446],[[0,'FFFFEAD0'],[.4,'E9FFCEBA'],[.75,'8AACC3FF'],[1,'41A5E6FF']]),'98FFF2CD',1.5);
vector(earR,'right ear blue seam','M 745 381 C 818 385 877 288 943 287',null,'B789DEFF',2.8);
vector(earR,'right ear lobe','M 757 424 C 805 447 834 519 809 554 C 776 576 773 518 753 487 Z',peach,'B4EAFBFF',1.8);
// Fine feelers, each pivots at its root rather than the tip.
const antenna=group('antennae',[638,347],head,[604,523]);
vector(antenna,'left feeler','M 569 345 C 635 267 570 155 495 181',null,grad('LinearGradient',[577,337,500,181],[[0,'85A6F1FF'],[1,'FFFFD49E']]),3);
vector(antenna,'crown feeler','M 626 314 C 646 247 635 174 579 139',null,'CFE7E7E0',2.5);
vector(antenna,'right feeler','M 744 426 C 760 353 779 306 753 263',null,'C6A2DAFF',3);
orb(antenna,'left feeler star',491,181,18);orb(antenna,'crown star',579,138,15);orb(antenna,'right feeler star',753,263,14);
// Silhouette and interior give the face its distinctive flame shape.
vector(head,'head silhouette','M 634 197 C 671 262 693 337 731 397 C 774 463 791 513 753 559 C 722 598 675 610 625 615 C 599 618 584 630 570 640 C 550 615 500 608 468 580 C 416 535 420 473 445 422 C 473 370 522 355 574 317 C 621 281 629 240 634 197 Z',grad('LinearGradient',[452,420,747,553],[[0,'E9B3D2FF'],[.15,'EED1C4D9'],[.3,'FF554E83'],[.6,'FF292B50'],[.86,'FF42416B'],[1,'F6AF97AF']]),'D6CDEFFF',2.6);
vector(head,'crown blue river','M 634 197 C 649 274 618 317 542 355 C 459 398 449 437 459 503 C 436 469 448 403 503 369 C 572 327 628 284 634 197 Z',grad('LinearGradient',[620,253,461,465],[[0,'FFB3F6FF'],[.4,'D96CCBFF'],[.67,'BA668FED'],[1,'00BFE8FF']]),null);
vector(head,'warm facial veil','M 633 228 C 624 311 562 339 516 377 C 458 425 441 491 485 548 C 519 590 554 588 574 622 C 605 605 669 607 705 590 C 670 618 610 610 570 640 C 548 605 491 606 464 575 C 411 515 425 457 457 408 C 496 352 589 337 633 228 Z',grad('LinearGradient',[436,359,600,631],[[0,'27B7C9FF'],[.28,'BEF9DAC3'],[.56,'FFE4C6BE'],[.8,'FFFFE6BC'],[1,'FFFFF7CD']]),'B6FFEBCF',1);
vector(head,'right cheek rim','M 670 284 C 701 411 794 468 760 539 C 738 587 682 601 632 607',null,grad('LinearGradient',[688,340,696,602],[[0,'35A1DCFF'],[.5,'FFADEEFF'],[1,'FFFFDBB9']]),4);
vector(head,'left cheek light','M 503 381 C 448 434 445 502 490 547 C 522 579 555 589 572 616',null,'ACFFF0C8',2.2);
// Eyes scale vertically around their own centres to blink; closed eye strokes replace them in sleep.
const eyeL=group('eye_left',[540,488],head,[604,523]);
vector(eyeL,'left eye socket','M 503 424 C 552 426 602 489 579 538 C 552 515 517 528 496 492 C 483 469 487 438 503 424 Z',grad('LinearGradient',[504,427,579,533],[[0,'FF101B39'],[.55,'FF342436'],[1,'FF805441']]),'AC755967',1.5);
glow(eyeL,'left eye warm bloom',546,506,48,'FFD87B','6A');
vector(eyeL,'left eye light','M 508 507 C 512 460 561 479 574 515 C 578 523 579 531 578 537 C 558 522 528 517 508 507 Z',grad('LinearGradient',[537,480,554,536],[[0,'FFFFE5A0'],[1,'FFFFFCD0']]),'FFFFEDAD',1.6);
vector(eyeL,'left eye reflection','M 500 459 C 506 438 518 434 530 440',null,'7F718EFA',7);
const eyeR=group('eye_right',[711,529],head,[604,523]);
vector(eyeR,'right eye socket','M 677 558 C 686 516 727 481 754 491 C 762 521 740 551 727 566 C 709 561 694 556 677 558 Z',grad('LinearGradient',[752,496,688,555],[[0,'FF15243D'],[.5,'FF382C43'],[1,'FF7F5746']]),'AF7B606E',1.5);
glow(eyeR,'right eye warm bloom',709,551,38,'FFD477','66');
vector(eyeR,'right eye light','M 679 557 C 695 530 714 518 727 535 C 734 545 731 556 727 566 C 710 561 696 557 679 557 Z','FFFFF1B0','FFFFEDB9',1.4);
vector(eyeR,'right eye reflection','M 738 501 C 750 507 745 523 738 533',null,'6485ABFF',4);
const closed=group('closed_eyes',[615,520],head,[604,523],{opacity:0});
vector(closed,'left resting eyelid','M 506 503 C 524 521 551 526 575 517',null,'FFFDE8AA',4);
vector(closed,'right resting eyelid','M 682 547 C 700 560 724 555 740 542',null,'FFFDE8AA',4);
const browL=group('brow_left',[574,450],head,[604,523]);
vector(browL,'left glowing brow','M 558 431 C 572 427 591 451 589 469 C 579 464 565 442 558 431 Z','FFFFE2A0');
const browR=group('brow_right',[722,486],head,[604,523]);
vector(browR,'right glowing brow','M 706 497 C 710 482 728 469 737 476 C 741 482 719 489 706 497 Z','FFFFD99C');
const mouth=group('mouth',[633,550],head,[604,523]);
vector(mouth,'gentle smile','M 621 545 C 627 554 636 556 645 551',null,'FFF8D491',2.8);
const worried=group('worried_mouth',[633,550],head,[604,523],{opacity:0});
vector(worried,'worried mouth curve','M 621 553 C 629 545 637 545 645 552',null,'FFF6CE98',2.6);
const gem=group('forehead_gem',[670,362],head,[604,523]);
glow(gem,'forehead glow',670,365,40,'9CDEFF','38');
vector(gem,'forehead diamond','M 670 315 L 689 360 L 671 405 L 653 356 Z',grad('LinearGradient',[661,324,682,398],[[0,'AF85C5FF'],[.5,'DEE3C9FF'],[1,'FFFFE4A1']]),'CBF7E4DB',1.2);
vector(gem,'forehead diamond facet','M 670 315 L 671 405 L 653 356 Z','3DDEF9FF');
ellipse(gem,'forehead pearl',668,421,4.2,6.4,'FFFFE7B6');
// Restrained fixed star field, attached to moving parts rather than a particle simulation.
let seed=271;function rand(){seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;}
function stars(parent,n,count,box,accept){const g=group(n,parent.p,parent,parent.p);for(let i=0,k=0;i<count&&k<2000;k++){const x=box[0]+rand()*box[2],y=box[1]+rand()*box[3];if(accept&&!accept(x,y))continue;const r=.7+rand()*1.3;ellipse(g,n+'_'+i++,x,y,r,r,(rand()>.6?'B9FFD8A1':'AAB5DDFF'));}return g;}
stars(earL,'left ear stars',32,[203,174,190,222],(x,y)=>x>208+(y-200)*.08&&y<355+(x-300)*.5&&y>155+(x-205)*.8);
stars(earR,'right ear stars',20,[801,330,115,140],(x,y)=>y>470-(x-800)*1.1&&y<493-(x-800)*.7);
stars(head,'crown stars',15,[588,300,130,132],(x,y)=>x>650-(y-300)*.58&&x<667+(y-300)*.5);
const twinkles=group('twinkles',[560,600]);
[[280,334],[351,365],[851,452],[696,336],[490,904],[613,978]].forEach(([x,y],i)=>{vector(twinkles,'star cross '+i,`M ${x-3} ${y} L ${x+3} ${y} M ${x} ${y-4} L ${x} ${y+4}`,null,'C8DFF4FF',1.1);});
const orbitFront=group('orbit_front',[560,600]);
vector(orbitFront,'front orbital thread','M 151 641 C 263 752 614 816 869 734 C 982 699 1014 618 940 580',null,grad('LinearGradient',[158,665,958,664],[[0,'B0C5EFFF'],[.5,'DA9CBFFF'],[.84,'D8CFEAFF'],[1,'009ED8FF']]),2.2);
orb(orbitFront,'orbit lower pearl',283,715,9);orb(orbitFront,'orbit floating pearl',628,823,17);
// State-only icons. Each is a vector bubble plus a separate pivoted symbol.
function badge(name,x,y,r){const g=group(name,[x,y],rig,[560,600],{opacity:0});glow(g,name+' aura',x,y,r*1.65,'90CAFF','22');ellipse(g,name+' shell',x,y,r,r,grad('RadialGradient',[-r*.2,-r*.4,r,0],[[0,'1CFFE0B7'],[.7,'163E5988'],[.88,'6888BDEF'],[1,'C0CEE9FF']]),'C4D4EEFF',2.2);vector(g,name+' rim',`M ${x-r*.87} ${y+r*.15} C ${x-r*.65} ${y+r*1.06} ${x+r*.44} ${y+r*1.1} ${x+r*.88} ${y+r*.3}`,null,'C395DFFF',2.5);return g;}
const bell=badge('bell_badge',956,486,46);const bellIcon=group('bell_swing',[956,456],bell,[956,486]);
glow(bellIcon,'bell light',957,484,36,'FFD084','88');
vector(bellIcon,'bell icon','M 939 495 C 947 484 940 470 950 464 C 950 453 963 453 963 464 C 975 470 969 484 977 495 C 978 499 938 499 939 495 Z','FFFFE7B4');ellipse(bellIcon,'bell clapper',958,503,4,4,'FFFFE7B4');
vector(bell,'bell ringing rays','M 990 447 L 995 436 M 1000 454 L 1010 446 M 1005 465 L 1018 462',null,'FFFFD29F',3);
const check=badge('check_badge',172,633,53);glow(check,'check light',172,633,40,'8ADFFF','88');vector(check,'check icon','M 149 630 L 164 646 L 191 616',null,'FFF1FCFF',8);
const bulb=badge('bulb_badge',846,742,63);glow(bulb,'bulb light',846,742,43,'FFE2A4','88');
vector(bulb,'lightbulb icon','M 836 758 C 835 748 829 746 829 736 C 829 716 861 716 862 736 C 863 746 855 750 855 758 Z','FFFFE8B3');
vector(bulb,'lightbulb base','M 836 765 L 855 765 M 839 771 L 852 771 M 843 777 L 849 777',null,'FFFFE0AF',3.5);
vector(bulb,'lightbulb rays','M 846 705 L 846 695 M 821 715 L 814 708 M 871 715 L 878 708 M 821 740 L 811 740 M 872 740 L 882 740',null,'FFFFD69E',3.5);
const thinking=group('thinking_motes',[866,535],rig,[560,600],{opacity:0});
for(let i=0;i<3;i++){const m=group('thought_'+i,[833+i*24,554-i*14],thinking,[866,535]);orb(m,'thought pearl '+i,...m.p,5+i*2);}
const sleep=group('sleep_motes',[850,447],rig,[560,600],{opacity:0});
[[0,0,1],[29,-28,.72],[52,-57,.48]].forEach(([dx,dy,s],i)=>vector(sleep,'sleep Z '+i,`M ${832+dx} ${438+dy} L ${850+dx} ${438+dy} L ${832+dx} ${458+dy} L ${852+dx} ${458+dy}`,null,'BCD9E5FF',2.5*s));
// Runtime control: one numeric view-model selector; eight fully connected states.
const names=['idle','sleeping','working_thinking','needs_attention','done_happy','idea','low_usage_worry','limit_reached'];
const vm=el('ViewModel',{id:'0:3',name:'PetController',defaultInstanceId:'0:4'},[el('ViewModelPropertyNumber',{name:'state',id:'0:5'}),el('ViewModelInstance',{name:'Default',id:'0:4',exports:true},[el('ViewModelInstanceNumber',{propertyValue:0,viewModelPropertyId:'0:5'})])]);root.kids.push(vm);
const machine=el('StateMachine',{name:'PetStateMachine',id:'0:2'});ab.kids.push(machine);const layer=el('StateMachineLayer',{name:'Pet States'});machine.kids.push(layer);
layer.kids.push(el('AnyState',{x:0,y:-160}),el('ExitState',{x:220,y:-160}),el('EntryState',{x:0,y:0},[el('StateTransition',{stateToId:id('state_idle')})]));
const baseline={float_control:{y:600,rotation:0,opacity:1},head:{rotation:0,y:-77},ear_left:{rotation:0},ear_right:{rotation:0},antennae:{rotation:0},body:{scaleY:1},fin_left:{rotation:0},fin_right:{rotation:0},tail_bone_0:{rotation:Math.PI/2},tail_bone_1:{rotation:0},tail_bone_2:{rotation:0},eye_left:{scaleY:1},eye_right:{scaleY:1},closed_eyes:{opacity:0},brow_left:{rotation:0},brow_right:{rotation:0},mouth:{opacity:1},worried_mouth:{opacity:0},forehead_gem:{opacity:1},twinkles:{opacity:.7},orbit_front:{opacity:.7},orbit_back:{opacity:.7},bell_badge:{opacity:0,scaleX:1,scaleY:1},check_badge:{opacity:0,scaleX:1,scaleY:1},bulb_badge:{opacity:0,scaleX:1,scaleY:1},bell_swing:{rotation:0},thinking_motes:{opacity:0},sleep_motes:{opacity:0},thought_0:{y:19},thought_1:{y:5},thought_2:{y:-9}};
const keys={x:13,y:14,rotation:15,scaleX:16,scaleY:17,opacity:18};
for(let s=0;s<8;s++){const n=names[s],dur=[240,360,180,180,150,150,240,360][s];const tracks=JSON.parse(JSON.stringify(baseline));function k(obj,p,frames){tracks[obj][p]=frames;}function val(obj,p,v){k(obj,p,[[0,v]]);}function wave(obj,p,base,amp,phase=0,period=dur){let arr=[];for(let f=0;f<=dur;f+=Math.min(15,period/4))arr.push([Math.round(f),+(base+amp*Math.sin(2*Math.PI*f/period+phase)).toFixed(5)]);k(obj,p,arr);}
wave('float_control','y',s===7?625:600,s===1?5:s===7?3:10);wave('float_control','rotation',0,s===6?.015:.01);
wave('head','rotation',s===1?.13:s===2?-.05:s===6?-.04:s===7?.10:0,s===7?.006:.018,.5);
wave('ear_left','rotation',s===1?-.12:s===6?-.10:s===7?-.17:0,.025,1);wave('ear_right','rotation',s===1?.16:s===6?.15:s===7?.23:0,.03,2);
wave('antennae','rotation',s===7?.05:0,.018,1);wave('body','scaleY',s===7?.95:1,.016,1);
wave('fin_left','rotation',s===1?-.08:0,.04,1);wave('fin_right','rotation',s===1?.13:0,.05,2);
wave('tail_bone_0','rotation',Math.PI/2,s===7?.01:.025,1);wave('tail_bone_1','rotation',s===1?.09:0,s===7?.015:.05,2);wave('tail_bone_2','rotation',s===1?.1:0,s===7?.02:.065,3);
wave('twinkles','opacity',s===7?.08:.65,s===7?.03:.2,1);wave('forehead_gem','opacity',s===7?.2:.85,s===7?.03:.15,1);
if(s!==1&&s!==7){const t=s===2?85:Math.min(140,dur-30);k('eye_left','scaleY',[[0,1],[t,1],[t+5,.035],[t+10,1],[dur,1]]);k('eye_right','scaleY',[[0,1],[t+1,1],[t+6,.035],[t+11,1],[dur,1]]);}
if(s===1||s===7){val('eye_left','scaleY',s===1?0:.3);val('eye_right','scaleY',s===1?0:.3);val('closed_eyes','opacity',s===1?1:0);val('sleep_motes','opacity',s===1?.7:0);val('float_control','opacity',s===1?.82:.4);val('orbit_front','opacity',s===1?.25:.1);val('orbit_back','opacity',s===1?.25:.1);}
if(s===2){val('thinking_motes','opacity',1);for(let j=0;j<3;j++)wave('thought_'+j,'y',19-j*14,5,j*1.6,60);val('brow_left','rotation',-.17);}
if(s===3){val('bell_badge','opacity',1);wave('bell_swing','rotation',0,.18,0,60);wave('bell_badge','scaleX',1,.035,0,90);wave('bell_badge','scaleY',1,.035,0,90);}
if(s===4||s===5){const b=s===4?'check_badge':'bulb_badge';val(b,'opacity',1);k(b,'scaleX',[[0,.75],[20,1.09],[38,1],[dur,1]]);k(b,'scaleY',[[0,.75],[20,1.09],[38,1],[dur,1]]);k('float_control','y',[[0,600],[20,574],[38,596],[55,585],[80,600],[dur,600]]);val('brow_left','rotation',-.09);val('brow_right','rotation',.12);if(s===4){k('eye_left','scaleY',[[0,1],[15,.12],[50,.12],[72,1],[dur,1]]);k('eye_right','scaleY',[[0,1],[15,.12],[50,.12],[72,1],[dur,1]]);} }
if(s===6||s===7){val('mouth','opacity',0);val('worried_mouth','opacity',1);val('brow_left','rotation',-.37);val('brow_right','rotation',.35);if(s===6){val('eye_left','scaleY',.82);val('eye_right','scaleY',.8);val('float_control','opacity',.84);}}
const anim=el('LinearAnimation',{name:n,id:id('anim_'+n),fps:60,duration:dur,loopValue:s===4||s===5?'oneShot':'loop'});ab.kids.push(anim);
for(const [obj,props] of Object.entries(tracks)){const ko=el('KeyedObject',{objectId:id(obj)});anim.kids.push(ko);for(const [prop,v]of Object.entries(props)){const kp=el('KeyedProperty',{propertyKey:keys[prop]});ko.kids.push(kp);const vals=typeof v==='number'?[[0,v]]:v;vals.forEach(([frame,value])=>kp.kids.push(el('KeyFrameDouble',{frame,value,interpolationType:'linear'})));}}
const st=el('AnimationState',{id:id('state_'+n),animationId:id('anim_'+n),reset:true,x:240+(s%4)*230,y:Math.floor(s/4)*210});layer.kids.push(st);
for(let j=0;j<8;j++)if(j!==s){const transition=el('StateTransition',{stateToId:id('state_'+names[j]),duration:j===1||j===7?320:180,enableEarlyExit:true});st.kids.push(transition);transition.kids.push(el('TransitionViewModelCondition',{opValue:'equal'},[el('TransitionPropertyViewModelComparator',{},[el('BindablePropertyNumber',{},[el('DataBindContext',{sourcePathIds:'0:3-0:5',propertyKey:636})])]),el('TransitionValueNumberComparator',{value:j})]));}
}
require('./usage-revision.js')({root,ab,vm,machine,master,rig,el,id,node,group,vector,ellipse,glow,paint,grad});
require('./batch1.js')({root,ab,vm,machine,master,rig,el,id,node,group,vector,ellipse,glow,paint,grad});
require('./batch1-colors.js')({root,vm,el,id});
require('./batch2.js')({root,ab,vm,machine,master,rig,el,id,group,vector,ellipse,glow,grad});
require('./batch3.js')({root,ab,vm,machine,master,rig,el,id,group,vector,ellipse,glow,grad});
require('./batch4.js')({root,ab,vm,machine,rig,el,id,group,vector,ellipse,glow,grad});
require('./batch5.js')({root,ab,vm,machine,master,rig,el,id,group,vector,ellipse,glow,grad});
function serialize(e,depth=0){let kids=e.kids;if(['Node','Artboard','RootBone','Bone'].includes(e.t)){const draw=['Node','Shape','RootBone','Bone'];const drawable=kids.filter(k=>draw.includes(k.t)).reverse();let i=0;kids=kids.map(k=>draw.includes(k.t)?drawable[i++]:k);}const attrs=Object.entries(e.a).map(([k,v])=>` ${k}="${String(v).replaceAll('&','&amp;').replaceAll('"','&quot;')}"`).join('');const pad='  '.repeat(depth);return kids.length?`${pad}<${e.t}${attrs}>\n${kids.map(k=>serialize(k,depth+1)).join('\n')}\n${pad}</${e.t}>`:`${pad}<${e.t}${attrs}/>`;}
fs.writeFileSync(path.join(out,'scene.rml'),serialize(root));fs.writeFileSync(path.join(out,'rive.yaml'),'name: celestial-fox\nmain: CelestialFox\n');fs.writeFileSync(path.join(__dirname,'pet-ids.json'),JSON.stringify(ids,null,2));console.log('Generated',seq-100,'named objects',out);
