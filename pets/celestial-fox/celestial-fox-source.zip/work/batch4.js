// Final cosmetic extension. The base artwork, prior timelines, rig and public IDs are retained.
module.exports=({root,ab,vm,machine,rig,el,id,group,vector,ellipse,glow,grad})=>{
 const find=(n,e=root)=>{if(e.a.name===n)return e;for(const c of e.kids){const f=find(n,c);if(f)return f;}};
 const inst=vm.kids.find(e=>e.t==='ViewModelInstance');
 for(const [n,t,v]of [['growth','Number',0],['palette','Number',0],['nightMode','Boolean',false]]){vm.kids.push(el('ViewModelProperty'+t,{name:n,id:id('property_'+n)}));inst.kids.push(el('ViewModelInstance'+t,{viewModelPropertyId:id('property_'+n),propertyValue:v}));}
 function*walk(e){yield e;for(const c of e.kids)yield*walk(c);}
 const cond=(n,t,v)=>el('TransitionViewModelCondition',{opValue:'equal'},[el('TransitionPropertyViewModelComparator',{},[el('BindableProperty'+t,{},[el('DataBindContext',{sourcePathIds:'0:3-'+id('property_'+n),propertyKey:t==='Boolean'?634:636})])]),el('TransitionValue'+t+'Comparator',{value:v})]);
 const trans=(to,c=[],duration=300)=>el('StateTransition',{stateToId:to,duration,enableEarlyExit:true},c);
 function layer(n){const l=el('StateMachineLayer',{name:n,id:id('b4_layer_'+n)}),entry=el('EntryState');l.kids.push(el('AnyState'),el('ExitState'),entry);machine.kids.push(l);return {l,entry};}
 function timeline(n,tracks){const a=el('LinearAnimation',{name:n,id:id('b4_anim_'+n),duration:1,fps:60,loopValue:'oneShot'});ab.kids.push(a);for(const [target,props]of tracks){const o=el('KeyedObject',{objectId:target.a.id});a.kids.push(o);for(const [key,value]of Object.entries(props))o.kids.push(el('KeyedProperty',{propertyKey:key},[el(typeof value==='string'?'KeyFrameColor':'KeyFrameDouble',{frame:0,value,interpolationType:'linear'})]));}return a;}
 function state(l,a,n){const s=el('AnimationState',{id:id('b4_state_'+n),animationId:a.a.id,reset:true});l.kids.push(s);return s;}
 function variants(label,property,type,values,tracks){const L=layer(label),ss=values.map((v,i)=>state(L.l,timeline('_'+label.toLowerCase().replaceAll(' ','_')+'_'+String(v),tracks[i]),label+'_'+v));L.entry.kids.push(trans(ss[0].a.id,[],0));for(const [i,s]of ss.entries())for(const [j,to]of ss.entries())if(i!==j)s.kids.push(trans(to.a.id,[cond(property,type,values[j])],label==='Night Mode'?400:300));return ss;}
 const tier1=[],tier2=[],tier3=[];
 const tail=find('tail_rig');
 const wisps=group('growth_tail_wisps',[450,650],tail,[450,650],{opacity:0,exportName:true});tier1.push(wisps);
 vector(wisps,'growth long peach wisp','M 495 892 C 544 954 678 960 724 1043 C 754 1100 697 1140 645 1147 C 706 1124 731 1092 706 1056 C 659 983 549 982 495 892 Z',grad('LinearGradient',[505,916,683,1143],[[0,'138EDCFF'],[.35,'67A5BFFF'],[.70,'D6FFD2C1'],[1,'E9FFF1C6']]),'93FFE9BF',1.4,true);
 vector(wisps,'growth long blue filament','M 493 882 C 525 957 673 931 739 1016 C 784 1076 723 1124 684 1131',null,grad('LinearGradient',[560,936,711,1118],[[0,'198FCFFF'],[.45,'A7BDEFFF'],[1,'DAFFDBBB']]),1.6,true);
 const coil=find('sitting_coiled_tail'),coilWisps=group('growth_coiled_wisps',[560,600],coil,[560,600],{opacity:0,exportName:true});tier1.push(coilWisps);
 vector(coilWisps,'growth coiled sweep','M 412 837 C 380 873 428 893 564 893 C 687 893 777 880 779 850 C 797 894 631 899 541 897 C 424 895 377 876 412 837 Z',grad('LinearGradient',[410,851,779,884],[[0,'5789CFFF'],[.55,'66B8DFFF'],[1,'CFFFF1C7']]),'70C8EFFF',1.2);
 const antenna=find('antennae'),pearl=group('growth_extra_pearl',[638,347],antenna,[638,347],{opacity:0,exportName:true});tier2.push(pearl);
 vector(pearl,'growth fourth feeler','M 666 329 C 701 289 727 222 703 178',null,grad('LinearGradient',[670,316,703,178],[[0,'B786D8FF'],[1,'F7FFE6B7']]),2);
 glow(pearl,'growth pearl glow',703,178,25,'FFDC9D','55');ellipse(pearl,'growth pearl',703,178,10,10,grad('RadialGradient',[-3,-4,10,0],[[0,'FFFFF7D8'],[.5,'F7FFDB9C'],[1,'66ACD9FF']]),'DCFFF1CD',1.1);
 // Extra stars are attached to the existing moving ear/head controls.
 for(const [parentName,coords]of [['ear_left',[[237,238],[257,282],[292,314],[329,337],[355,350],[308,305],[369,369]]],['ear_right',[[844,422],[867,402],[888,379],[871,435],[823,453]]],['head',[[649,328],[668,356],[647,383],[680,405],[620,389]]]]){
  const p=find(parentName),stars=group('growth_stars_'+parentName,p.p,p,p.p,{opacity:0,exportName:true});tier2.push(stars);
  coords.forEach(([x,y],i)=>{ellipse(stars,'growth star '+parentName+' '+i,x,y,1.6,1.6,i%2?'FFF1F8FF':'FFFFE6BA');if(i%3===0)vector(stars,'growth cross '+parentName+' '+i,`M ${x-3.5} ${y} L ${x+3.5} ${y} M ${x} ${y-3.5} L ${x} ${y+3.5}`,null,'B9E1F3FF',1);});
 }
 const head=find('head'),halo=group('growth_crown_halo',[628,248],head,[604,523],{opacity:0,exportName:true});tier3.push(halo);
 // Between the ears, below the existing highest antenna tip: no new artboard padding.
 vector(halo,'growth halo soft','M 527 246 C 548 213 675 208 721 237 C 759 264 621 289 552 269 C 535 265 523 256 527 246',null,'40BFE7FF',12);
 vector(halo,'growth halo arc','M 527 246 C 548 213 675 208 721 237 C 759 264 621 289 552 269 C 535 265 523 256 527 246',null,grad('LinearGradient',[528,240,718,250],[[0,'80B7E7FF'],[.45,'EEFFF0C5'],[1,'A3B2E6FF']]),2.5);
 vector(halo,'growth crown rays','M 579 218 L 576 206 M 626 216 L 626 199 M 673 220 L 678 207',null,'BFFFE6B9',2);
 ellipse(halo,'growth crown jewel',626,198,3.3,3.3,'FFFFEDBE');
 variants('Growth','growth','Number',[0,1,2,3],[0,1,2,3].map(level=>[...tier1.map(n=>[n,{18:level>=1?1:0}]),...tier2.map(n=>[n,{18:level>=2?1:0}]),...tier3.map(n=>[n,{18:level>=3?1:0}])]));
 // Palette colors preserve the authored alpha/lightness; palette 0 is byte-exact original paint.
 function rgbToHsl(r,g,b){r/=255;g/=255;b/=255;const hi=Math.max(r,g,b),lo=Math.min(r,g,b),d=hi-lo,l=(hi+lo)/2;let h=0,s=0;if(d){s=d/(1-Math.abs(2*l-1));h=hi===r?((g-b)/d)%6:hi===g?(b-r)/d+2:(r-g)/d+4;h=(h*60+360)%360;}return [h,s,l];}
 function hslToRgb(h,s,l){const c=(1-Math.abs(2*l-1))*s,x=c*(1-Math.abs((h/60)%2-1)),m=l-c/2;const v=h<60?[c,x,0]:h<120?[x,c,0]:h<180?[0,c,x]:h<240?[0,x,c]:h<300?[x,0,c]:[c,0,x];return v.map(v=>Math.round((v+m)*255));}
 function paletteColor(hex,p){if(!p)return hex;const a=hex.slice(0,2),rgb=[2,4,6].map(i=>parseInt(hex.slice(i,i+2),16));let [h,s,l]=rgbToHsl(...rgb);const cool=h>=145&&h<=300;if(cool){h=[0,330+(h-235)*.16,168+(h-235)*.15,269+(h-235)*.15][p];s*=p===1?.82:p===2?.8:.84;}else{if(h>300)h-=360;h=[0,43+(h-40)*.10,191+(h-40)*.10,221+(h-40)*.05][p];s*=p===1?.94:p===2?.68:.16;}return a+hslToRgb((h+360)%360,Math.min(1,s),l).map(v=>v.toString(16).padStart(2,'0')).join('').toUpperCase();}
 const paints=[];let counter=0;
 function collect(e,protectedPaint=false){const name=e.a.name||'';protectedPaint||=name.includes('legibility')||name==='coiled tail rim';if(!protectedPaint&&(e.t==='SolidColor'||e.t==='GradientStop')&&e.a.colorValue&&!e.kids.some(c=>c.t==='DataBindContext')){if(!e.a.id)e.a.id=id('b4_palette_paint_'+counter++);paints.push(e);}for(const c of e.kids)collect(c,protectedPaint);}
 collect(rig); // Usage meter geometry/paint is a sibling and never enters the palette layer.
 variants('Palette','palette','Number',[0,1,2,3],[0,1,2,3].map(p=>paints.map(e=>[e,{[e.t==='SolidColor'?37:38]:paletteColor(e.a.colorValue,p)}])));
 // Night mode changes light intensity through wrappers, leaving palette and dark rims intact.
 const night=[];let nightCounter=0;
 function nightWrap(parent,child,amount){const w=el('Node',{name:'night_light_'+nightCounter,id:id('night_light_'+nightCounter++),exportName:true},[child]);parent.kids[parent.kids.indexOf(child)]=w;night.push([w,amount]);}
 function soften(parent){for(const e of [...parent.kids]){const name=e.a.name||'';if(name.includes('legibility')||name==='coiled tail rim')continue;const radial=e.t==='Shape'&&e.kids.some(p=>p.t==='Fill'&&p.kids.some(g=>g.t==='RadialGradient'));const stars=e.t==='Node'&&(name.endsWith('ear stars')||name==='crown stars'||name==='twinkles'||name.startsWith('growth_stars_'));if(radial||stars||['left eye light','right eye light','growth halo soft','growth halo arc','growth crown rays','growth crown jewel'].includes(name)){nightWrap(parent,e,radial?.48:stars?.6:.78);continue;}soften(e);}}
 soften(rig);
 variants('Night Mode','nightMode','Boolean',[false,true],[false,true].map(on=>night.map(([n,amount])=>[n,{18:on?amount:1}])));
 require('fs').writeFileSync('work/batch4-meta.json',JSON.stringify({palettePaints:paints.length,nightWrappers:night.length,tierGroups:[tier1,tier2,tier3].map(gs=>gs.map(g=>g.a.name)),palettes:['celestial blue/peach','rose/gold','mint/aqua','violet/silver']},null,2));
};
