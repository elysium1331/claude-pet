module.exports=({root,ab,vm,machine,master,rig,el,id,group})=>{
 function*walk(e=root){yield e;for(const c of e.kids)yield*walk(c);}const find=n=>[...walk()].find(e=>e.a.name===n),copy=e=>JSON.parse(JSON.stringify(e));
 const bind=(e,n,k,converter)=>e.kids.push(el('DataBindContext',{sourcePathIds:'0:3-'+(n==='state'?'0:5':id('property_'+n)),propertyKey:k,...(converter?{converterId:id(converter)}:{})}));
 const cond=(n,t,v,op='equal')=>el('TransitionViewModelCondition',{opValue:op},[el('TransitionPropertyViewModelComparator',{},[el('BindableProperty'+t,{},[el('DataBindContext',{sourcePathIds:'0:3-'+(n==='state'?'0:5':id('property_'+n)),propertyKey:{Trigger:686,Boolean:634,Number:636}[t]})])]),el('TransitionValue'+t+'Comparator',{value:v})]);
 const tr=(to,c=[],duration=0,extra={})=>el('StateTransition',{stateToId:to,duration,enableEarlyExit:true,...extra},c),end=(to)=>tr(to,[],0,{enableExitTime:true,exitTimeIsPercetange:true,exitTime:100});
 function layer(n){const l=el('StateMachineLayer',{name:n,id:id('b6_layer_'+n)}),any=el('AnyState'),entry=el('EntryState');l.kids.push(any,el('ExitState'),entry);machine.kids.push(l);return {l,any,entry};}
 function track(a,n,k,values){let o=a.kids.find(e=>e.t==='KeyedObject'&&e.a.objectId===find(n).a.id);if(!o){o=el('KeyedObject',{objectId:find(n).a.id});a.kids.push(o);}o.kids=o.kids.filter(p=>Number(p.a.propertyKey)!==k);o.kids.push(el('KeyedProperty',{propertyKey:k},(Array.isArray(values)?values:[[0,values]]).map(([frame,value,hold])=>el('KeyFrameDouble',{frame,value,interpolationType:hold?'hold':'linear'}))));}
 function anim(n,d,t){const a=el('LinearAnimation',{name:n,id:id('b6_anim_'+n),fps:60,duration:d,loopValue:'oneShot'});ab.kids.push(a);for(const [name,ps]of Object.entries(t))for(const [k,v]of Object.entries(ps))track(a,name,Number(k),v);return a;}
 function state(l,a,n){const s=el('AnimationState',{animationId:a.a.id,id:id('b6_state_'+n),reset:true});l.kids.push(s);return s;}
 function inside(parent,n){const w=el('Node',{name:n,id:id(n),exportName:true},parent.kids);w.p=parent.p;parent.kids=[w];return w;}
 // Reflect the complete settled pose, including its existing rotation, around artboard x=280.
 // The usage meters and stats anchors are siblings and never enter this transform.
 const projection=el('Node',{name:'facing_projection',id:id('facing_projection'),exportName:true},[rig]);master.kids[master.kids.indexOf(rig)]=projection;
 const symbols=['bell_badge','check_badge','bulb_badge','thinking_motes','sleep_motes','orbit_front','orbit_back','busy_workpad','confused_motes','disconnected_signal','event_error_motes'];
 const counter=[];for(const n of symbols)if(find(n))counter.push(inside(find(n),'upright_'+n));
 const right=find('_facing_right'),left=find('_facing_left');left.kids=copy(right.kids);
 for(const [a,sign]of [[right,1],[left,-1]]){track(a,'facing_projection',16,sign);track(a,'facing_projection',13,560*(1-sign));for(const n of counter)track(a,n.a.name,16,sign);}
 // Preserve 21-frame timing and appendage choreography; only the turn can be compressed.
 for(const [name,dir]of [['_turn_left',-1],['_turn_right',1]]){const a=find(name);for(const o of a.kids){if(o.t!=='KeyedObject')continue;for(const p of o.kids){const key=Number(p.a.propertyKey),v=[16,17,18].includes(key)?1:0;for(const k of p.kids)if(Number(k.a.frame)===0||Number(k.a.frame)===21)k.a.value=v;}}
  const start=-dir,values=[[0,start],[4,start*.9],[8,start*.45],[10,start*.08,true],[11,dir*.08],[15,dir*.60],[21,dir]];
  track(a,'facing_projection',16,values);track(a,'facing_projection',13,values.map(([f,s,h])=>[f,560*(1-s),h]));for(const n of counter)track(a,n.a.name,16,[[0,start,true],[11,dir]]);
 }
 // Left-facing lookBack now inherits the reflection, so the old compensation is redundant.
 for(const o of find('_lookBack_left_projection').kids)for(const p of o.kids)for(const k of p.kids)k.a.value=0;
 const instance=vm.kids.find(e=>e.t==='ViewModelInstance');for(const n of ['earLeft','earRight','tailSway']){vm.kids.push(el('ViewModelPropertyNumber',{name:n,id:id('property_'+n)}));instance.kids.push(el('ViewModelInstanceNumber',{viewModelPropertyId:id('property_'+n),propertyValue:0}));}
 const V=v=>el('FormulaTokenValue',{operationValue:v}),I=()=>el('FormulaTokenInput'),O=o=>el('FormulaTokenOperation',{operationType:o}),P=()=>el('FormulaTokenParenthesisOpen'),C=()=>el('FormulaTokenParenthesisClose'),A=()=>el('FormulaTokenArgumentSeparator');
 const fn=(n,...args)=>[el('FormulaTokenFunction',{functionType:n}),...args.flatMap((a,i)=>[...(i?[A()]:[]),...(Array.isArray(a)?a:[a])]),C()];const src=n=>{const e=V(0);bind(e,n,777);return e;};
 const eq=n=>fn('max',V(0),[V(1),O('subtract'),...fn('max',[src('state'),O('subtract'),V(n)],[V(n),O('subtract'),src('state')])]);
 function formula(n,t){root.kids.push(el('DataConverterFormula',{name:n,id:id(n)},t));}
 const factor=()=>[P(),V(1),O('subtract'),V(.6),O('multiply'),P(),...eq(1),O('add'),...eq(8),C(),C()];

 for(const [n,scale]of [['look_head_x',3],['look_head_turn',.035],['look_eye_x',9]]){const e=find(n);e.t='DataConverterFormula';e.a={name:n,id:e.a.id};e.kids=[...fn('min',V(1),fn('max',V(-1),I())),O('multiply'),V(scale),O('multiply'),src('facing')];}
 find('held_drag_angle').kids.push(O('multiply'),src('facing'));
 const strengthNodes=[];
 function offset(target,property,amount,name,additive){
 const ear=property!=='tailSway';
 // Keep extreme offsets inside the established artboard envelope.
 const lower=ear?[V(-1)]:[V(-1),O('add'),V(.65),O('multiply'),P(),...eq(7),O('add'),...eq(14),O('add'),...eq(12),O('add'),...eq(15),C(),O('add'),V(.85),O('multiply'),...eq(8)];
 const upper=ear?[P(),V(.80),O('subtract'),V(.15),O('multiply'),...eq(10),C()]:[V(1)];
 const input=()=>fn('min',V(1),fn('max',V(-1),I())); const tokens=[P(),...fn('max',V(0),input()),O('multiply'),...upper,O('add'),...fn('min',V(0),input()),O('multiply'),P(),V(0),O('subtract'),P(),...lower,C(),C(),C(),O('multiply'),V(amount),O('multiply'),...factor()];
 if(!ear)tokens.push(O('multiply'),P(),V(1),O('subtract'),V(2),O('multiply'),...eq(8),C());
 formula(name+'_value',tokens);const control=group(name+'_target',[0,0],ab,[0,0],{exportName:true});bind(control,property,15,name+'_value');const constraint=el('RotationConstraint',{name:name+'_offset',id:id(name+'_offset'),targetId:control.a.id,sourceSpaceValue:'local',destSpaceValue:'local',offset:additive,strength:1});target.kids.push(constraint);strengthNodes.push(constraint.a.name);}
 // Place the ear control inside its transform, exactly at the established ear-base pivot.
 offset(inside(find('ear_left'),'ambient_ear_left'),'earLeft',25*Math.PI/180,'ambient_left',false);
 offset(inside(find('ear_right'),'ambient_ear_right'),'earRight',-25*Math.PI/180,'ambient_right',false);
 // Original animated bone rotations remain intact; constraints add distributed curl on top.
 for(const [i,degrees]of [-3,-10,-15].entries())offset(find('tail_bone_'+i),'tailSway',degrees*Math.PI/180,'ambient_tail_'+i,true);
 // The sitting tail is a coiled vector assembly, and follows a restrained version of the curl.
 offset(inside(find('sitting_coiled_tail'),'ambient_coiled_tail'),'tailSway',-4*Math.PI/180,'ambient_coil',false);
 const on=Object.fromEntries(strengthNodes.map(n=>[n,{172:1}])),off=Object.fromEntries(strengthNodes.map(n=>[n,{172:0}]));
 const gate=layer('Ambient Reaction Gate'),rest=state(gate.l,anim('_ambient_enabled',1,on),'ambient_enabled');gate.entry.kids.push(tr(rest.a.id));
 for(const [name,d]of [['trickSpin',114],['trickFlip',114],['land',72]]){const s=state(gate.l,anim('_ambient_suppressed_'+name,d,off),'ambient_suppressed_'+name);gate.any.kids.push(tr(s.a.id,[cond(name,'Trigger',0)]));s.kids.push(end(rest.a.id));}
 const suppressed=gate.l.kids.filter(e=>e.t==='AnimationState'&&e!==rest);
 const recover=state(gate.l,anim('_ambient_recover',24,off),'ambient_recover');recover.kids.push(end(rest.a.id));for(const p of vm.kids.filter(e=>e.t==='ViewModelPropertyTrigger'&&!['land','trickSpin','trickFlip'].includes(e.a.name)))for(const s of suppressed)s.kids.unshift(tr(recover.a.id,[cond(p.a.name,'Trigger',0)]));
 // Held has independent priority, so releasing during a trick still respects the trick gate.
 const held=layer('Ambient Held Gate'),h0=state(held.l,anim('_ambient_unheld',1,{}),'ambient_unheld'),h1=state(held.l,anim('_ambient_held',1,off),'ambient_held');held.entry.kids.push(tr(h0.a.id));h0.kids.push(tr(h1.a.id,[cond('held','Boolean',true)]));h1.kids.push(tr(h0.a.id,[cond('held','Boolean',false)]));
 require('fs').writeFileSync('work/batch6-meta.json',JSON.stringify({properties:['earLeft','earRight','tailSway'],symbols:counter.map(n=>n.a.name),constraints:strengthNodes,changedInternalTimelines:['_facing_left','_facing_right','_turn_left','_turn_right','_lookBack_left_projection']},null,2));
};
