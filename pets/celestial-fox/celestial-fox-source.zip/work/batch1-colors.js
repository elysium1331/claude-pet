// App-controlled meter colors. Append after Batch 1 so all delivered IDs stay stable.
module.exports=({root,vm,el,id})=>{
 const find=(name,e=root)=>{if(e.a.name===name)return e;for(const c of e.kids){const r=find(name,c);if(r)return r;}};
 const instance=vm.kids.find(e=>e.t==='ViewModelInstance');
 for(const name of ['session','weekly','fable']){
  const prop=name+'Color',pid=id('property_'+prop);
  vm.kids.push(el('ViewModelPropertyColor',{name:prop,id:pid}));
  instance.kids.push(el('ViewModelInstanceColor',{viewModelPropertyId:pid,propertyValue:'FFB7E7FF'}));
  const bind=(e,key)=>e.kids.push(el('DataBindContext',{sourcePathIds:'0:3-'+pid,propertyKey:key}));
  // Retain legacy object IDs, but disable numeric threshold-driven overlay bands.
  for(const band of ['amber','high']){const g=find(name+'_'+band);g.a.opacity=0;g.kids=g.kids.filter(e=>e.t!=='DataBindContext');}
  const ring=find(name+' calm ring'),stroke=ring.kids.find(e=>e.t==='Stroke');
  bind(stroke.kids.find(e=>e.t==='SolidColor'),37);
  // A faint feathered copy follows the same trimmed arc as the sharp fill ring.
  const halo=el('Stroke',{name:name+' ring glow',thickness:11,cap:'butt',join:'round'},[
   el('SolidColor',{colorValue:'FFB7E7FF'}),el('Feather',{strength:5}),
   el('TrimPath',{id:id(name+'_color_glow_trim'),name:name+' ring glow fill',start:0,end:0,modeValue:'sequential'},[
    el('DataBindContext',{sourcePathIds:'0:3-'+id('property_'+name),propertyKey:115,converterId:id('usage_fraction')})])]);
  bind(halo.kids[0],37);
  const geometry=JSON.parse(JSON.stringify(ring.kids.find(e=>e.t==='PointsPath')));geometry.a.name=name+' ring glow path';
  const haloShape=el('Shape',{...ring.a,id:id(name+'_color_glow'),name:name+' color ring glow',opacity:.22},[geometry,halo]);
  const calm=find(name+'_calm');calm.kids.splice(calm.kids.indexOf(ring),0,haloShape);
  // Tint the existing ambient halo and core; keep gradient transparency in the paint.
  for(const [shapeName,opacity]of [[name+' aura',.16],[name+' calm core',112/255]]){
   const shape=find(shapeName),fill=shape.kids.find(e=>e.t==='Fill'),gradient=fill.kids.find(e=>e.t==='RadialGradient');
   if(shapeName.endsWith(' aura'))shape.a.opacity=opacity;
   else {const wrapper=el('Node',{name:name+' color core opacity',id:id(name+'_color_core_opacity'),opacity},[shape]);calm.kids[calm.kids.indexOf(shape)]=wrapper;}
   gradient.kids=[el('GradientStop',{position:0,colorValue:'FFB7E7FF'}),el('GradientStop',{position:1,colorValue:'00000000'})];
   bind(gradient.kids[0],38);
  }
  for(let dot=1;dot<=3;dot++){const d=find(name+' identity dot '+dot);if(d)d.kids.find(e=>e.t==='Fill').kids.find(e=>e.t==='SolidColor').a.colorValue='FFFFFFFF';}
 }
};
