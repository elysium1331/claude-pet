module.exports=({root,ab,vm,machine,master,rig,el,id,node,group,vector,ellipse,glow,paint,grad})=>{
 const find=(name,e=root)=>{if(e.a.name===name)return e;for(const c of e.kids){const r=find(name,c);if(r)return r;}};
 const duration={lookAround:180,stretch:180,yawn:150,orbPlay:210,tailChase:180,scratchEar:120,sneeze:90,perkUp:90,appear:60,disappear:48};
 const inst=vm.kids.find(x=>x.t==='ViewModelInstance');
 function property(name,type,value){vm.kids.push(el('ViewModelProperty'+type,{name,id:id('property_'+name)}));inst.kids.push(el('ViewModelInstance'+type,{viewModelPropertyId:id('property_'+name),propertyValue:value}));}
 Object.keys(duration).forEach(n=>property(n,'Trigger',0));property('statsOpen','Boolean',false);property('statsSide','Number',0);property('hovered','Boolean',false);property('lookX','Number',0);property('lookY','Number',0);
 function bind(e,name,key,converter){e.kids.push(el('DataBindContext',{sourcePathIds:'0:3-'+(name==='state'?'0:5':id('property_'+name)),propertyKey:key,...(converter?{converterId:id(converter)}:{})}));}
 function map(name,minInput,maxInput,minOutput,maxOutput){root.kids.push(el('DataConverterRangeMapper',{name,id:id(name),minInput,maxInput,minOutput,maxOutput,clampLower:true,clampUpper:true}));}
 function wrapChildren(parent,name,attrs={}){const n=el('Node',{name,id:id(name),exportName:true,...attrs},parent.kids);parent.kids=[n];n.p=parent.p;return n;}
 function wrapChild(parent,child,name,attrs={}){const n=el('Node',{name,id:id(name),exportName:true,...attrs},[child]);parent.kids[parent.kids.indexOf(child)]=n;n.p=parent.p;return n;}
 function condition(name,type,value,op='equal'){return el('TransitionViewModelCondition',{opValue:op},[el('TransitionPropertyViewModelComparator',{},[el('BindableProperty'+type,{},[el('DataBindContext',{sourcePathIds:'0:3-'+(name==='state'?'0:5':id('property_'+name)),propertyKey:{Number:636,Boolean:634,Trigger:686}[type]})])]),el('TransitionValue'+type+'Comparator',{value})]);}
 function trans(to,conds=[],ms=240,more={}){return el('StateTransition',{stateToId:to,duration:ms,enableEarlyExit:true,...more},conds);}
 function timeline(name,frames,tracks,loop='oneShot'){const a=el('LinearAnimation',{name,id:id('animation_'+name),fps:60,duration:frames,loopValue:loop});ab.kids.push(a);for(const [obj,props]of Object.entries(tracks)){const ko=el('KeyedObject',{objectId:find(obj)?.a.id??id(obj)});a.kids.push(ko);for(const [key,v]of Object.entries(props)){const kp=el('KeyedProperty',{propertyKey:key});ko.kids.push(kp);(typeof v==='number'?[[0,v]]:v).forEach(([frame,value,ease])=>{const k=el('KeyFrameDouble',{frame,value,interpolationType:ease?'cubic':'linear'});if(ease)k.kids.push(el('CubicEaseInterpolator',{x1:.25,y1:.1,x2:.25,y2:1}));kp.kids.push(k);});}}return a;}
 function layer(name){const l=el('StateMachineLayer',{name,id:id('layer_'+name)});machine.kids.push(l);const any=el('AnyState',{x:0,y:-160}),entry=el('EntryState',{x:0,y:0});l.kids.push(any,el('ExitState',{x:220,y:-160}),entry);return {l,any,entry};}
 function state(l,anim,name,x=240,y=0){const s=el('AnimationState',{id:id('state_'+name),animationId:anim.a.id,reset:true,x,y});l.kids.push(s);return s;}
 function boolLayer(name,prop,off,on){const {l,entry}=layer(name),a=state(l,off,name+'_off'),b=state(l,on,name+'_on',480);entry.kids.push(trans(a.a.id,[],0));a.kids.push(trans(b.a.id,[condition(prop,'Boolean',true)],240));b.kids.push(trans(a.a.id,[condition(prop,'Boolean',false)],240));return {a,b};}
 // Layer transforms are separate from the original keyed rig, preserving its animation definitions.
 const appearance=wrapChild(ab,master,'visibility_control');
 const dust=group('materialize_sparks',[0,0],appearance,[0,0],{opacity:0});
 [[200,220],[400,180],[370,320],[180,400],[335,495],[270,570],[120,140],[435,280],[240,330],[160,480]].forEach(([x,y],i)=>{glow(dust,'materialize glow '+i,x,y,12,'B5DDFF','66');vector(dust,'materialize star '+i,`M ${x-3} ${y} L ${x+3} ${y} M ${x} ${y-3} L ${x} ${y+3}`,null,'FFF3E9D0',1.2);});
 const rx=wrapChildren(rig,'reaction_body');
 const loungeScale=wrapChild(rig,rx,'lounging_scale');
 const head=find('head');const gaze=wrapChild(rx,head,'gaze_head');
 const rxHead=wrapChild(gaze,head,'reaction_head');
 const eyeL=find('eye_left'),eyeR=find('eye_right');
 const rxEyeL=wrapChild(head,eyeL,'reaction_eye_left'),rxEyeR=wrapChild(head,eyeR,'reaction_eye_right');
 wrapChild(head,rxEyeL,'gaze_eye_left');wrapChild(head,rxEyeR,'gaze_eye_right');
 wrapChild(head,find('ear_left'),'hover_ear_left');wrapChild(head,find('ear_right'),'hover_ear_right');
 wrapChild(rx,find('fin_left'),'reaction_fin_left');wrapChild(rx,find('fin_right'),'reaction_fin_right');
 wrapChild(find('reaction_fin_right'),find('fin_right'),'scratch_hand');
 const frontFin=find('reaction_fin_right');rx.kids.splice(rx.kids.indexOf(frontFin),1);rx.kids.push(frontFin);
 wrapChild(rx,find('tail_rig'),'reaction_tail');
 wrapChild(head,find('mouth'),'reaction_smile');
 const rxMouth=group('reaction_open_mouth',[633,553],head,[604,523],{opacity:0});
 ellipse(rxMouth,'yawn mouth',633,553,15,20,'FF243054','FFFFDEA4',2);
 ellipse(rxMouth,'yawn tongue',633,563,8,5,'A4EBAFB4');
 const rxSparks=group('reaction_sparks',[660,570],rx,[560,600],{opacity:0});
 [[-45,-20],[20,-45],[62,5],[-5,30],[40,38],[-62,18]].forEach(([x,y],i)=>{glow(rxSparks,'reaction spark '+i,660+x,570+y,10,'FFDFB1','88');vector(rxSparks,'reaction star '+i,`M ${656+x} ${570+y} L ${664+x} ${570+y} M ${660+x} ${566+y} L ${660+x} ${574+y}`,null,'FFFFE3B1',2);});
 for(const side of ['left','right'])wrapChild(find('hover_ear_'+side),find('ear_'+side),'reaction_ear_'+side);
 const hoverLight=group('hover_eye_glow',[615,510],head,[604,523],{opacity:0});glow(hoverLight,'hover left eye',546,505,39,'FFE3AE','38');glow(hoverLight,'hover right eye',711,547,32,'FFE3AE','38');
 map('look_head_x',-1,1,-3,3);map('look_head_y',-1,1,-2,2);map('look_head_turn',-1,1,-.035,.035);map('look_eye_x',-1,1,-9,9);map('look_eye_y',-1,1,-6,6);
 bind(gaze,'lookX',13,'look_head_x');bind(gaze,'lookY',14,'look_head_y');bind(gaze,'lookX',15,'look_head_turn');
 for(const n of ['gaze_eye_left','gaze_eye_right']){bind(find(n),'lookX',13,'look_eye_x');bind(find(n),'lookY',14,'look_eye_y');}
 boolLayer('Hover','hovered',timeline('_hover_off',1,{'hover_ear_left':{15:0},'hover_ear_right':{15:0},'hover_eye_glow':{18:0}}),timeline('_hover_on',1,{'hover_ear_left':{15:.03},'hover_ear_right':{15:-.03},'hover_eye_glow':{18:1}}));
 // Lounging gets a new state; original state values, transitions and tracks retain their identities.
 const oldLayer=find('Pet States');const oldStates=oldLayer.kids.filter(k=>k.t==='AnimationState');
 const loungeTracks={float_control:{14:[[0,1134],[120,1134],[240,1134],[360,1134],[480,1134]],15:1.25,18:1},head:{14:-77,15:-1.08},ear_left:{15:[[0,-.08],[320,-.08],[330,.01],[344,-.08],[480,-.08]]},ear_right:{15:.06},antennae:{15:.025},body:{17:[[0,1],[120,1.025],[240,1],[360,1.025],[480,1]]},fin_left:{15:.3},fin_right:{15:.85},tail_bone_0:{15:2.15},tail_bone_1:{15:[[0,.07],[100,.07],[150,.16],[200,.07],[480,.07]]},tail_bone_2:{15:[[0,-.1],[150,-.16],[220,-.1],[480,-.1]]},eye_left:{17:[[0,.45],[200,.45],[215,.03],[230,.45],[480,.45]]},eye_right:{17:[[0,.45],[205,.45],[220,.03],[235,.45],[480,.45]]},closed_eyes:{18:0},brow_left:{15:0},brow_right:{15:0},mouth:{18:1},worried_mouth:{18:0},forehead_gem:{18:.7},twinkles:{18:.5},orbit_front:{18:0},orbit_back:{18:0},bell_badge:{18:0,16:1,17:1},check_badge:{18:0,16:1,17:1},bulb_badge:{18:0,16:1,17:1},bell_swing:{15:0},thinking_motes:{18:0},sleep_motes:{18:0},thought_0:{14:19},thought_1:{14:5},thought_2:{14:-9}};
 const loungeAnim=timeline('lounging',480,loungeTracks,'loop');const loungeState=state(oldLayer,loungeAnim,'lounging',240,420);
 const settleTracks={};const idleKeys=find('idle').kids;
 for(const [obj,props]of Object.entries(loungeTracks)){settleTracks[obj]={};for(const [key,track]of Object.entries(props)){const keyed=idleKeys.find(k=>k.a.objectId===find(obj).a.id)?.kids.find(k=>Number(k.a.propertyKey)===Number(key));const start=Number(keyed?.kids[0]?.a.value??0),end=typeof track==='number'?track:track[0][1];settleTracks[obj][key]=[[0,start],[24,start],[48,end,1]];}}
 const settleState=state(oldLayer,timeline('_lounging_settle',48,settleTracks),'lounging_settle',480,420);
 oldStates.forEach(s=>s.kids.push(trans(settleState.a.id,[condition('state','Number',8)],180)));
 settleState.kids.push(trans(loungeState.a.id,[condition('state','Number',8)],180,{enableExitTime:true,exitTimeIsPercetange:true,exitTime:100}));
 oldStates.forEach((s,i)=>settleState.kids.push(trans(s.a.id,[condition('state','Number',i)],360)));
 oldStates.forEach((s,i)=>loungeState.kids.push(trans(s.a.id,[condition('state','Number',i)],360)));
 const lo=timeline('_lounging_clear',1,{'lounging_scale':{16:1,17:1,13:0,14:0},'reaction_fin_right':{14:0}}),ln=timeline('_lounging_transform',1,{'lounging_scale':{16:.7,17:.7,13:0,14:0},'reaction_fin_right':{14:-12}});
 const lc=layer('Lounging Scale'),lcs0=state(lc.l,lo,'lounge_clear'),lcs1=state(lc.l,ln,'lounge_scale',480);lc.entry.kids.push(trans(lcs0.a.id,[],0));lcs0.kids.push(trans(lcs1.a.id,[condition('state','Number',8)],360));lcs1.kids.push(trans(lcs0.a.id,[condition('state','Number',8,'notEqual')],360));
 const loungeOrbit={};for(const [i,n]of ['session','weekly','fable'].entries()){const xs=[],ys=[];for(let f=0;f<=2160;f+=36){const t=-2.45+i*2*Math.PI/3+f*Math.PI*2/2160;xs.push([f,-300+150*Math.cos(t)]);ys.push([f,100+106*Math.sin(t)]);}loungeOrbit[n+'_meter']={13:xs,14:ys};}
 const orbitLayer=find('Usage Orbit'),normalOrbit=orbitLayer.kids.find(k=>k.t==='AnimationState'),restOrbit=state(orbitLayer,timeline('_usage_orbit_lounging',2160,loungeOrbit,'loop'),'usage_orbit_lounging',480);
 const departTracks={};for(const [i,n]of ['session','weekly','fable'].entries()){const theta=-2.45+i*2*Math.PI/3;departTracks[n+'_meter']={13:[[0,-300+150*Math.cos(theta)],[24,-300+150*Math.cos(theta+24*Math.PI*2/2160)]],14:[[0,100+106*Math.sin(theta)],[24,100+106*Math.sin(theta+24*Math.PI*2/2160)]]};}
 const departOrbit=state(orbitLayer,timeline('_usage_orbit_depart',24,departTracks),'usage_orbit_depart',720);
 normalOrbit.kids.push(trans(restOrbit.a.id,[condition('state','Number',8)],360));restOrbit.kids.push(trans(departOrbit.a.id,[condition('state','Number',8,'notEqual')],180));
 departOrbit.kids.push(trans(normalOrbit.a.id,[],360,{enableExitTime:true,exitTimeIsPercetange:true,exitTime:100}),trans(restOrbit.a.id,[condition('state','Number',8)],180));
 // Reactions are additive wrapper poses: every fidget returns all of its channels to identity.
 const neutral={'reaction_body':{13:0,14:0,15:0,16:1,17:1},'reaction_head':{13:0,14:0,15:0},'reaction_eye_left':{13:0,14:0,17:1},'reaction_eye_right':{13:0,14:0,17:1},'scratch_hand':{13:0,14:0},'reaction_fin_left':{15:0},'reaction_fin_right':{15:0},'reaction_tail':{15:0},'reaction_ear_left':{15:0},'reaction_ear_right':{15:0},'reaction_smile':{18:1},'reaction_open_mouth':{18:0,17:1},'reaction_sparks':{18:0,16:1,17:1,13:100,14:-30}};
 const reactionLayer=layer('Fidgets');const rest=state(reactionLayer.l,timeline('_reaction_rest',1,neutral),'reaction_rest');reactionLayer.entry.kids.push(trans(rest.a.id,[],0));
 function values(tracks,obj,key,list){tracks[obj][key]=list;}
 for(const name of Object.keys(duration).filter(n=>!['appear','disappear'].includes(n))){const d=duration[name],t=JSON.parse(JSON.stringify(neutral));const k=(obj,key,...v)=>values(t,obj,key,v);const f=(q)=>Math.round(q*d);
 if(name==='lookAround'){for(const eye of ['reaction_eye_left','reaction_eye_right']){k(eye,13,[0,0],[30,-10,1],[65,10,1],[105,5,1],[145,0,1],[d,0]);k(eye,14,[0,0],[65,0],[110,-7,1],[145,0,1],[d,0]);}k('reaction_head',15,[0,0],[35,-.07,1],[75,.065,1],[115,-.03,1],[155,0,1],[d,0]);}
 if(name==='stretch'){k('reaction_ear_left',15,[0,0],[45,-.1,1],[95,-.1],[d,0,1]);k('reaction_ear_right',15,[0,0],[45,.1,1],[95,.1],[d,0,1]);k('reaction_body',17,[0,1],[45,1.10,1],[95,1.10],[135,.98,1],[d,1,1]);k('reaction_body',16,[0,1],[45,.94,1],[95,.94],[d,1,1]);k('reaction_fin_left',15,[0,0],[50,-.55,1],[100,-.55],[d,0,1]);k('reaction_fin_right',15,[0,0],[50,.45,1],[100,.45],[d,0,1]);k('reaction_tail',15,[0,0],[100,-.12],[120,.13],[145,-.05],[d,0]);}
 if(name==='yawn'){k('reaction_open_mouth',18,[0,0],[25,1],[105,1],[135,0],[d,0]);k('reaction_smile',18,[0,1],[25,0],[105,0],[135,1],[d,1]);k('reaction_open_mouth',17,[0,.2],[40,1.6,1],[88,1.6],[135,.2,1],[d,1]);for(const e of ['reaction_eye_left','reaction_eye_right'])k(e,17,[0,1],[35,.14,1],[95,.14],[135,1,1],[d,1]);k('reaction_head',15,[0,0],[50,-.08,1],[100,-.08],[d,0,1]);}
 if(name==='orbPlay'){k('reaction_fin_right',15,[0,0],[45,-.45,1],[62,.35],[85,-.12],[120,.45],[150,-.1],[d,0,1]);k('reaction_body',15,[0,0],[50,-.07,1],[110,.04,1],[d,0,1]);k('reaction_head',15,[0,0],[60,.09,1],[135,-.04,1],[d,0,1]);k('reaction_eye_left',14,[0,0],[50,6],[140,6],[d,0]);k('reaction_eye_right',14,[0,0],[50,6],[140,6],[d,0]);}
 if(name==='tailChase'){k('reaction_body',15,[0,0],[30,.08,1],[75,-.08],[120,.06],[d,0,1]);k('reaction_body',16,[0,1],[45,.07,1],[85,-1,1],[125,-.07,1],[165,1,1],[d,1]);k('reaction_body',17,[0,1],[40,.96,1],[120,.96],[d,1,1]);k('reaction_tail',15,[0,0],[40,.2],[80,-.2],[120,.2],[d,0]);}
 if(name==='scratchEar'){k('scratch_hand',13,[0,0],[25,180,1],[85,180],[d,0,1]);k('scratch_hand',14,[0,0],[25,-40,1],[85,-40],[d,0,1]);k('reaction_head',15,[0,0],[25,.09,1],[85,.09],[d,0,1]);k('reaction_fin_right',15,[0,0],[25,-.8],[36,-.6],[47,-.9],[58,-.6],[69,-.9],[80,-.6],[d,0]);}
 if(name==='sneeze'){k('reaction_body',17,[0,1],[25,1.05,1],[36,.88],[47,1.03],[d,1,1]);k('reaction_head',15,[0,0],[25,-.08],[36,.1],[47,-.02],[d,0,1]);for(const e of ['reaction_eye_left','reaction_eye_right'])k(e,17,[0,1],[28,.05],[45,.05],[65,1],[d,1]);k('reaction_sparks',18,[0,0],[30,0],[36,1],[65,0],[d,0]);k('reaction_sparks',16,[0,.2],[30,.2],[65,1.4],[d,1]);k('reaction_sparks',17,[0,.2],[30,.2],[65,1.4],[d,1]);}
 if(name==='perkUp'){k('reaction_body',14,[0,0],[22,12,1],[45,-20,1],[70,-5],[d,0,1]);k('reaction_body',17,[0,1],[22,.94],[45,1.06],[d,1,1]);k('reaction_head',15,[0,0],[35,-.04],[d,0]);}
 const a=timeline(name,d,t);const s=state(reactionLayer.l,a,'reaction_'+name,480+(Object.keys(duration).indexOf(name)%4)*230,Math.floor(Object.keys(duration).indexOf(name)/4)*200);
 reactionLayer.any.kids.push(trans(s.a.id,[condition(name,'Trigger',0)],180));s.kids.push(trans(rest.a.id,[],180,{enableExitTime:true,exitTimeIsPercetange:true,exitTime:100}));
 if(name==='perkUp')s.kids.push(el('ListenerViewModelChange',{},[el('BindablePropertyNumber',{propertyValue:0},[el('DataBindContext',{sourcePathIds:'0:3-0:5',propertyKey:636,direction:true})])]));
 }
 // Visibility reactions latch invisible on disappear; appear reverses it from any state.
 const vis=layer('Visibility'),v0=state(vis.l,timeline('_visible',1,{'visibility_control':{18:1},'materialize_sparks':{18:0}}),'visible');vis.entry.kids.push(trans(v0.a.id,[],0));
 const va=state(vis.l,timeline('appear',60,{'visibility_control':{18:[[0,0],[12,.3],[42,1,1],[60,1]]},'materialize_sparks':{18:[[0,0],[12,1],[34,.8],[55,0],[60,0]]}}),'appear',480);
 const vd=state(vis.l,timeline('disappear',48,{'visibility_control':{18:[[0,1],[12,.88],[40,.05,1],[48,0]]},'materialize_sparks':{18:[[0,0],[12,1],[28,1],[48,0]]}}),'disappear',720);
 vis.any.kids.push(trans(va.a.id,[condition('appear','Trigger',0)],180),trans(vd.a.id,[condition('disappear','Trigger',0)],180));va.kids.push(trans(v0.a.id,[],180,{enableExitTime:true,exitTimeIsPercetange:true,exitTime:100}));
 // Stats travel has three stages: slide sideways below the face, rise/lower outside it,
 // then merge above the crown or below the tail. Original orbit keeps advancing underneath.
 // The meeting point follows the grounded pose as well as statsSide.
 const fv=v=>el('FormulaTokenValue',{operationValue:v}),op=o=>el('FormulaTokenOperation',{operationType:o}),cl=()=>el('FormulaTokenParenthesisClose'),sep=()=>el('FormulaTokenArgumentSeparator');
 const loungeFactor=()=>{const v=fv(0);bind(v,'state',777);return [el('FormulaTokenFunction',{functionType:'min'}),fv(1),sep(),el('FormulaTokenFunction',{functionType:'max'}),fv(0),sep(),v,op('subtract'),fv(7),cl(),cl()];};
 root.kids.push(el('DataConverterFormula',{name:'stats_target_y',id:id('stats_target_y')},[fv(130),op('add'),fv(640),op('multiply'),...loungeFactor(),op('add'),el('FormulaTokenInput'),op('multiply'),el('FormulaTokenParenthesisOpen'),fv(1070),op('subtract'),fv(640),op('multiply'),...loungeFactor(),cl()]));
 root.kids.push(el('DataConverterFormula',{name:'stats_target_x',id:id('stats_target_x')},[fv(560),op('add'),...loungeFactor(),op('multiply'),el('FormulaTokenParenthesisOpen'),fv(60),op('subtract'),fv(420),op('multiply'),el('FormulaTokenInput'),cl()]));
 map('stats_weekly_route',7,8,1020,100);
 const targets=group('stats_targets',[0,0],master,[0,0]);
 const meet=group('stats_meeting_point',[560,50],targets,[0,0],{exportName:true});bind(meet,'statsSide',14,'stats_target_y');bind(meet,'statsSide',13,'stats_target_x');
 const bubble=group('stats_bubble',[0,0],meet,[560,50],{opacity:0});bubble.a.x=0;bubble.a.y=0;bubble.p=[0,0];glow(bubble,'stats merge halo',0,0,45,'DDEFFF','99');ellipse(bubble,'stats merge bubble',0,0,24,24,'EEDDFAFF','FFFFFFFF',2);
 const statsOff={},statsOpen={},statsClose={};
 function set3(obj,key,off,open,close){statsOff[obj]??={};statsOpen[obj]??={};statsClose[obj]??={};statsOff[obj][key]=off;statsOpen[obj][key]=open;statsClose[obj][key]=close;}
 for(const [i,n]of ['session','weekly','fable'].entries()){const meter=find(n+'_meter');const visual=wrapChildren(meter,n+'_stats_visual');visual.a.scaleX=1;visual.a.scaleY=1;
 const edge=i===1?1020:100;const anchor=group(n+'_side_anchor',[edge,930],targets,[0,0]);const top=group(n+'_travel_anchor',[edge,50],targets,[0,0]);bind(top,'statsSide',14,'stats_target_y');
 if(i===1){bind(anchor,'state',13,'stats_weekly_route');bind(top,'state',13,'stats_weekly_route');}
 [anchor,top,meet].forEach((target,j)=>{const name=n+'_stats_constraint_'+j;meter.kids.push(el('TranslationConstraint',{id:id(name),name,targetId:target.a.id,strength:0}));set3(name,172,0,[[0,0],[j*6,0],[(j+1)*6,1,1],[24,1]],[[0,1],[(2-j)*6,1],[(3-j)*6,0,1],[24,0]]);});
 set3(visual.a.name,18,1,[[0,1],[16,1],[20,0],[24,0]],[[0,0],[4,0],[8,1],[24,1]]);
 for(const k of [16,17])set3(visual.a.name,k,1,[[0,1],[5,.55,1],[16,.22],[24,.22]],[[0,.22],[8,.22],[19,1,1],[24,1]]);
 }
 set3('stats_bubble',18,0,[[0,0],[14,0],[18,1],[24,0]],[[0,0],[3,1],[8,0],[24,0]]);for(const k of [16,17])set3('stats_bubble',k,1,[[0,.3],[16,.3],[21,1.6],[24,2]],[[0,1.6],[4,1],[8,.3],[24,1]]);
 const sl=layer('Stats Panel'),so=state(sl.l,timeline('_stats_orbit',1,statsOff),'stats_orbit'),sp=state(sl.l,timeline('_stats_open',24,statsOpen),'stats_open',480),sc=state(sl.l,timeline('_stats_close',24,statsClose),'stats_close',720);sl.entry.kids.push(trans(so.a.id,[],0));so.kids.push(trans(sp.a.id,[condition('statsOpen','Boolean',true)],0));sp.kids.push(trans(sc.a.id,[condition('statsOpen','Boolean',false)],180));sc.kids.push(trans(sp.a.id,[condition('statsOpen','Boolean',true)],180),trans(so.a.id,[],0,{enableExitTime:true,exitTimeIsPercetange:true,exitTime:100}));
 // Save metadata for rendering/verification, never embedded in the runtime artifact.
 require('fs').writeFileSync('work/batch1-meta.json',JSON.stringify({duration},null,2));
};








