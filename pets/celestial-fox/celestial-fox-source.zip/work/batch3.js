module.exports=({root,ab,vm,machine,master,rig,el,id,group,vector,ellipse,glow,grad})=>{
 const find=(n,e=root)=>{if(e.a.name===n)return e;for(const c of e.kids){const f=find(n,c);if(f)return f;}};
 const copy=e=>JSON.parse(JSON.stringify(e));function*walk(e){yield e;for(const c of e.kids)yield*walk(c);}
 const inst=vm.kids.find(e=>e.t==='ViewModelInstance');
 const durations={petted:120,tickled:90,eat:120,catchOrb:90,land:48,bonk:60,dizzy:120,trickSpin:90,trickFlip:90,levelUp:180};
 function prop(n,t,v){vm.kids.push(el('ViewModelProperty'+t,{name:n,id:id('property_'+n)}));inst.kids.push(el('ViewModelInstance'+t,{viewModelPropertyId:id('property_'+n),propertyValue:v}));}
 for(const n of Object.keys(durations))prop(n,'Trigger',0);prop('held','Boolean',false);prop('dragLean','Number',0);prop('facing','Number',1);prop('happiness','Number',50);
 const bind=(e,n,k,conv)=>e.kids.push(el('DataBindContext',{sourcePathIds:'0:3-'+(n==='state'?'0:5':id('property_'+n)),propertyKey:k,...(conv?{converterId:id(conv)}:{})}));
 const cond=(n,t,v,op='equal')=>el('TransitionViewModelCondition',{opValue:op},[el('TransitionPropertyViewModelComparator',{},[el('BindableProperty'+t,{},[el('DataBindContext',{sourcePathIds:'0:3-'+(n==='state'?'0:5':id('property_'+n)),propertyKey:{Trigger:686,Boolean:634,Number:636}[t]})])]),el('TransitionValue'+t+'Comparator',{value:v})]);
 const trans=(to,conds=[],ms=240,extra={})=>el('StateTransition',{stateToId:to,duration:ms,enableEarlyExit:true,...extra},conds);
 const end=(to,ms=180)=>trans(to,[],ms,{enableExitTime:true,exitTimeIsPercetange:true,exitTime:100});
 function timeline(n,d,t,loop='oneShot'){const a=el('LinearAnimation',{name:n,id:id('b3_anim_'+n),fps:60,duration:d,loopValue:loop});ab.kids.push(a);for(const [obj,props]of Object.entries(t)){const o=el('KeyedObject',{objectId:find(obj)?.a.id??id(obj)});a.kids.push(o);for(const [key,vals]of Object.entries(props)){const p=el('KeyedProperty',{propertyKey:key});o.kids.push(p);for(const [frame,value,ease]of typeof vals==='number'?[[0,vals]]:vals){const k=el('KeyFrameDouble',{frame,value,interpolationType:ease?'cubic':'linear'});if(ease)k.kids.push(el('CubicEaseInterpolator',{x1:.25,y1:.1,x2:.25,y2:1}));p.kids.push(k);}}}return a;}
 function state(l,a,n){const s=el('AnimationState',{id:id('b3_state_'+n),animationId:a.a.id,reset:true});l.kids.push(s);return s;}
 function layer(n){const l=el('StateMachineLayer',{name:n,id:id('b3_layer_'+n)}),any=el('AnyState'),entry=el('EntryState');machine.kids.push(l);l.kids.push(any,el('ExitState'),entry);return {l,any,entry};}
 function base(n){const t={};for(const o of find(n).kids){if(o.t!=='KeyedObject')continue;const target=[...walk(root)].find(e=>e.a.id===o.a.objectId);t[target.a.name]={};for(const p of o.kids)t[target.a.name][p.a.propertyKey]=Number(p.kids[0].a.value);}return t;}
 function wrap(parent,child,n){const w=el('Node',{name:n,id:id(n),exportName:true},[child]);w.p=parent.p;parent.kids[parent.kids.indexOf(child)]=w;return w;}
 function set(t,n,k,v){t[n]??={};t[n][k]=v;}
 function wave(t,n,k,b,a,d,cycles=1,phase=0){set(t,n,k,Array.from({length:25},(_,i)=>[Math.round(i*d/24),b+a*Math.sin(i*Math.PI*2*cycles/24+phase)]));}
 const V=v=>el('FormulaTokenValue',{operationValue:v}),I=()=>el('FormulaTokenInput'),O=o=>el('FormulaTokenOperation',{operationType:o}),C=()=>el('FormulaTokenParenthesisClose'),P=()=>el('FormulaTokenParenthesisOpen'),A=()=>el('FormulaTokenArgumentSeparator');
 const fn=(n,...args)=>[el('FormulaTokenFunction',{functionType:n}),...args.flatMap((a,i)=>[...(i?[A()]:[]),...(Array.isArray(a)?a:[a])]),C()];
 const src=n=>{const v=V(0);bind(v,n,777);return v;};
 const eq=n=>fn('max',V(0),[V(1),O('subtract'),...fn('max',[src('state'),O('subtract'),V(n)],[V(n),O('subtract'),src('state')])]);
 function formula(n,t){const f=el('DataConverterFormula',{name:n,id:id(n)},t);root.kids.push(f);return f;}
 const rx=find('reaction_body'),head=find('head');
 const facing=wrap(rig,find('lounging_scale'),'play_facing');
 formula('play_facing_value',[V(1),O('add'),P(),I(),O('subtract'),V(1),C(),O('multiply'),...eq(12)]);bind(facing,'facing',16,'play_facing_value');
 const sittingScale=wrap(find('lounging_scale'),rx,'sitting_scale');
 const lean=wrap(sittingScale,rx,'held_lean');
 const trick=wrap(lean,rx,'play_trick');
 wrap(find('reaction_tail'),find('tail_rig'),'play_tail_visibility');
 // A compact coiled vector tail provides a stable ground contact at y=590.
 const coil=group('sitting_coiled_tail',[560,600],rx,[560,600],{opacity:0,exportName:true});rx.kids.splice(rx.kids.indexOf(coil),1);rx.kids.unshift(coil);
 vector(coil,'coiled tail rim','M 455 730 C 380 768 351 847 398 879 C 449 912 716 900 755 860 C 799 814 731 786 680 811 C 755 826 722 870 625 871 C 543 872 432 867 440 825 C 443 792 481 770 455 730 Z','88233F66','8A24466D',8);
 vector(coil,'coiled celestial tail','M 455 730 C 380 768 351 847 398 879 C 449 900 716 900 755 860 C 799 814 731 786 680 811 C 755 826 722 870 625 871 C 543 872 432 867 440 825 C 443 792 481 770 455 730 Z',grad('LinearGradient',[420,760,710,900],[[0,'AC8CBFFF'],[.42,'D1BEE4FF'],[.64,'D3F2C0C0'],[1,'FFFFEDC0']]),'DAE6F4FF',2.5);
 vector(coil,'coiled peach fold','M 407 853 C 463 896 647 893 727 857 C 669 901 470 908 410 874 Z','BFFFF1C4');
 vector(coil,'coiled light thread','M 428 768 C 365 858 448 890 583 888 C 730 888 783 827 714 817',null,'BFFFE5B3',2);
 // Ground contour is exact; the rim extends a few pixels outside it.
 ellipse(coil,'sitting contact pearl',572,896,45,4,'7EC8E9FF');
 const sitNeutral={float_control:{13:560},sitting_scale:{16:1,17:1},play_tail_visibility:{18:1},sitting_coiled_tail:{18:0}};
 const sitOn={float_control:{13:640},sitting_scale:{16:.65,17:.65},play_tail_visibility:{18:0},sitting_coiled_tail:{18:1}};
 const sl=layer('Sitting Shape'),s0=state(sl.l,timeline('_sitting_clear',1,sitNeutral),'sitting_clear'),s1=state(sl.l,timeline('_sitting_shape',1,sitOn),'sitting_shape');sl.entry.kids.push(trans(s0.a.id,[],0));s0.kids.push(trans(s1.a.id,[cond('state','Number',13)],360));s1.kids.push(trans(s0.a.id,[cond('state','Number',13,'notEqual')],360));
 const activityClear=base('_activity_clear');
 const chase={...base('idle'),...copy(activityClear)};wave(chase,'float_control',14,600,6,120,2);wave(chase,'head',15,-.05,.035,120,2);wave(chase,'fin_left',15,-.2,.35,120,4);wave(chase,'fin_right',15,.25,.32,120,4,Math.PI);wave(chase,'tail_bone_1',15,.06,.13,120,2);wave(chase,'tail_bone_2',15,0,.17,120,2,1);chase.orbit_front[18]=0;chase.orbit_back[18]=0;
 const sit={...base('idle'),...copy(activityClear)};sit.float_control={13:640,14:1025,15:0,18:1};sit.head={14:-77,15:.05};sit.fin_left[15]=.32;sit.fin_right[15]=.52;sit.orbit_front[18]=0;sit.orbit_back[18]=0;wave(sit,'body',17,1.25,.012,300);sit.eye_left[17]=[[0,.88],[165,.88],[171,.04],[181,.88],[300,.88]];sit.eye_right[17]=[[0,.88],[168,.88],[174,.04],[184,.88],[300,.88]];sit.ear_left[15]=[[0,-.03],[235,-.03],[244,.04],[258,-.03],[300,-.03]];sit.ear_right[15]=.04;
 const petLayer=find('Pet States'),oldStates=petLayer.kids.filter(e=>e.t==='AnimationState');
 const chaseState=state(petLayer,timeline('chasing',120,chase,'loop'),'chasing'),sitState=state(petLayer,timeline('sitting',300,sit,'loop'),'sitting');
 const settle={};const idle=base('idle');for(const [n,props]of Object.entries(sit)){settle[n]={};for(const [k,v]of Object.entries(props)){const from=idle[n]?.[k]??(n==='float_control'&&Number(k)===13?560:0),to=typeof v==='number'?v:v[0][1];settle[n][k]=[[0,from],[24,from],[48,to,1]];}}
 const settleState=state(petLayer,timeline('_sitting_settle',48,settle),'sitting_settle');settleState.kids.push(trans(sitState.a.id,[cond('state','Number',13)],180,{enableExitTime:true,exitTimeIsPercetange:true,exitTime:100}));
 for(const s of oldStates)s.kids.push(trans(chaseState.a.id,[cond('state','Number',12)],360),trans(settleState.a.id,[cond('state','Number',13)],180));
 const stateNames=['idle','sleeping','working_thinking','needs_attention','done_happy','idea','low_usage_worry','limit_reached','lounging','working_busy','confused','disconnected'];
 const oldTargets=stateNames.map(n=>oldStates.find(s=>s.a.animationId===find(n).a.id));oldTargets[8]=oldStates.find(s=>s.a.animationId===find('_lounging_settle').a.id);
 for(const s of [chaseState,sitState,settleState]){oldTargets.forEach((to,i)=>s.kids.push(trans(to.a.id,[cond('state','Number',i)],360)));if(s!==chaseState)s.kids.push(trans(chaseState.a.id,[cond('state','Number',12)],360));if(s===chaseState)s.kids.push(trans(settleState.a.id,[cond('state','Number',13)],180));}
 // Sitting uses the safe left-side grounded meter orbit. Existing state behavior is unchanged.
 const ol=find('Usage Orbit'),os=ol.kids.filter(e=>e.t==='AnimationState');const restOrbit=os.find(s=>s.a.animationId===find('_usage_orbit_lounging').a.id);
 for(const s of os)if(s!==restOrbit)s.kids.unshift(trans(restOrbit.a.id,[cond('state','Number',13)],360));
 for(const t of restOrbit.kids.filter(e=>e.t==='StateTransition'))t.kids.push(cond('state','Number',13,'notEqual'));
 // Grounded stats anchors are overridden by floating targets while held.
 const grounded=n=>[P(),...eq(n),C()];
 find('stats_target_y').kids=[V(130),O('add'),V(640),O('multiply'),...grounded(8),O('add'),V(520),O('multiply'),...grounded(13),O('add'),I(),O('multiply'),P(),V(1070),O('subtract'),V(640),O('multiply'),...grounded(8),O('subtract'),V(520),O('multiply'),...grounded(13),C()];
 find('stats_target_x').kids=[V(560),O('add'),V(80),O('multiply'),...grounded(13),O('add'),...grounded(8),O('multiply'),P(),V(60),O('subtract'),V(420),O('multiply'),I(),C()];
 find('stats_weekly_route_exact').kids=[V(1020),O('subtract'),V(920),O('multiply'),P(),...grounded(8),O('add'),...grounded(13),C()];
 // Subtle default-neutral happiness on resting poses only.
 const restFactor=()=>[P(),...eq(0),O('add'),...eq(8),O('add'),...eq(13),C()];
 const mood=()=>[P(),...fn('min',V(1),fn('max',V(-1),[P(),I(),O('subtract'),V(50),C(),O('divide'),V(50)])),C()];
 formula('happiness_eye',[V(1),O('add'),V(.1),O('multiply'),...mood(),O('multiply'),...restFactor()]);
 formula('happiness_brow_left',[V(-.07),O('multiply'),...mood(),O('multiply'),...restFactor()]);formula('happiness_brow_right',[V(.07),O('multiply'),...mood(),O('multiply'),...restFactor()]);
 formula('happiness_warmth',[V(.35),O('multiply'),...fn('max',V(0),mood()),O('multiply'),...restFactor()]);
 for(const side of ['left','right']){const eyeParent=find('activity_eye_'+side),e=wrap(eyeParent,find('reaction_eye_'+side),'happiness_eye_'+side);bind(e,'happiness',17,'happiness_eye');const brow=wrap(head,find('brow_'+side),'happiness_brow_pose_'+side);bind(brow,'happiness',15,'happiness_brow_'+side);}
 const warmth=group('happiness_warm_glow',[568,620],find('body'),[568,620],{opacity:0});glow(warmth,'warm resting heart',575,671,85,'FFD08B','55');bind(warmth,'happiness',18,'happiness_warmth');
 // Held overrides only the base rig, so reactions remain layered and the app state is retained.
 formula('held_drag_angle',[...fn('min',V(1),fn('max',V(-1),I())),O('multiply'),V(-.16)]);
 const dragTarget=group('held_drag_target',[0,0],ab,[0,0],{exportName:true});bind(dragTarget,'dragLean',15,'held_drag_angle');lean.kids.push(el('RotationConstraint',{name:'held_drag_constraint',id:id('held_drag_constraint'),targetId:dragTarget.a.id,strength:0,sourceSpaceValue:'local',destSpaceValue:'local'}));
 const heldOff={held_drag_constraint:{172:0}};
 const heldTracks={...base('idle'),...copy(activityClear),...copy(sitNeutral),lounging_scale:{16:1,17:1},held_drag_constraint:{172:1}};
 formula('held_stats_y',[V(130),O('add'),I(),O('multiply'),V(1070)]);
 for(const [n,x,y,meeting]of [['stats_meeting_point',560,130,true],...['session','weekly','fable'].flatMap((n,i)=>[[n+'_travel_anchor',i===1?1020:100,130,true],[n+'_side_anchor',i===1?1020:100,930,false]])]){const anchor=group('held_'+n,[x,y],master,[0,0],{exportName:true});if(meeting)bind(anchor,'statsSide',14,'held_stats_y');const constraint='held_'+n+'_constraint';find(n).kids.push(el('TranslationConstraint',{name:constraint,id:id(constraint),targetId:anchor.a.id,strength:0}));set(heldOff,constraint,172,0);set(heldTracks,constraint,172,1);}
 heldTracks.float_control={13:560,14:580,15:0,18:1};heldTracks.head={14:-86,15:0};heldTracks.eye_left[17]=1.10;heldTracks.eye_right[17]=1.10;heldTracks.brow_left[15]=-.13;heldTracks.brow_right[15]=.13;heldTracks.body[17]=1.06;heldTracks.orbit_front[18]=0;heldTracks.orbit_back[18]=0;wave(heldTracks,'fin_left',15,-.85,.14,180);wave(heldTracks,'fin_right',15,.35,.16,180,1,1);wave(heldTracks,'tail_bone_1',15,.06,.12,180);wave(heldTracks,'tail_bone_2',15,.1,.14,180,1,1);
 const hl=layer('Held Pose'),h0=state(hl.l,timeline('_held_clear',1,heldOff),'held_clear'),h1=state(hl.l,timeline('held',180,heldTracks,'loop'),'held');hl.entry.kids.push(trans(h0.a.id,[],0));h0.kids.push(trans(h1.a.id,[cond('held','Boolean',true)],240));h1.kids.push(trans(h0.a.id,[cond('held','Boolean',false)],400));
 const ho=layer('Held Meter Orbit'),ho0=state(ho.l,timeline('_held_orbit_clear',1,{}),'held_orbit_clear');const standardOrbit={};for(const [i,n]of ['session','weekly','fable'].entries()){standardOrbit[n+'_meter']={13:[],14:[]};for(let f=0;f<=1440;f+=24){const th=-2.45+i*2*Math.PI/3+f*2*Math.PI/1440;standardOrbit[n+'_meter'][13].push([f,335*Math.cos(th)]);standardOrbit[n+'_meter'][14].push([f,100*Math.sin(th)]);}}
 const ho1=state(ho.l,timeline('_held_orbit',1440,standardOrbit,'loop'),'held_orbit');const depart=state(ho.l,timeline('_held_orbit_depart',24,base('_usage_orbit_depart')),'held_orbit_depart');ho.entry.kids.push(trans(ho0.a.id,[],0));for(const s of [8,13])ho0.kids.push(trans(depart.a.id,[cond('held','Boolean',true),cond('state','Number',s)],180));ho0.kids.push(trans(ho1.a.id,[cond('held','Boolean',true)],400));depart.kids.push(end(ho1.a.id,400),trans(ho0.a.id,[cond('held','Boolean',false)],240));ho1.kids.push(trans(ho0.a.id,[cond('held','Boolean',false)],240));
 // Play accents remain separate from state-owned badges and app-controlled meters.
 const fxRestTracks={play_trick:{13:0,14:0,15:0,16:1,17:1}};
 const hearts=group('play_warm_sparks',[615,520],head,[604,523],{opacity:0,exportName:true});for(const [i,[x,y]]of [[-80,10],[70,-65],[130,40],[-40,-80]].entries()){glow(hearts,'petting warmth '+i,615+x,520+y,16,'FFD5B2','66');vector(hearts,'petting star '+i,`M ${610+x} ${520+y} L ${620+x} ${520+y} M ${615+x} ${515+y} L ${615+x} ${525+y}`,null,'FFFFDCB1',2);}fxRestTracks.play_warm_sparks={18:0,15:0};
 const spark=group('play_food_spark',[633,553],head,[604,523],{opacity:0,exportName:true});glow(spark,'food glow',633,553,23,'FFE7AA','88');ellipse(spark,'food core',633,553,6,6,'FFFFF5D0');fxRestTracks.play_food_spark={18:0,13:29,14:30,16:1,17:1};
 const stars=group('play_dizzy_stars',[604,320],head,[604,523],{opacity:0,exportName:true});for(let i=0;i<5;i++){const x=604+85*Math.cos(i*2*Math.PI/5),y=320+20*Math.sin(i*2*Math.PI/5);vector(stars,'dizzy star '+i,`M ${x-5} ${y} L ${x+5} ${y} M ${x} ${y-5} L ${x} ${y+5}`,null,'FFFFE8B7',2.5);}fxRestTracks.play_dizzy_stars={18:0,15:0,16:1};
 const crown=group('play_level_burst',[560,590],rx,[560,600],{opacity:0,exportName:true});for(let i=0;i<10;i++){const t=i*Math.PI*2/10,x=560+185*Math.cos(t),y=590+155*Math.sin(t);vector(crown,'level ray '+i,`M ${x} ${y} L ${x+15*Math.cos(t)} ${y+15*Math.sin(t)}`,null,'A3FFE9BE',3);glow(crown,'level glint '+i,x,y,10,'C1E9FF','55');}fxRestTracks.play_level_burst={18:0,16:1,17:1};
 const fx=layer('Play Reactions'),fxRest=state(fx.l,timeline('_play_fx_rest',1,fxRestTracks),'play_fx_rest');fx.entry.kids.push(trans(fxRest.a.id,[],0));
 const fidgets=find('Fidgets'),fidgetAny=fidgets.kids.find(e=>e.t==='AnyState'),bodyRest=fidgets.kids.find(s=>s.a.animationId===find('_reaction_rest').a.id);
 const b2fx=find('Activity Reactions'),b2rest=b2fx.kids.find(s=>s.a.animationId===find('_activity_fx_rest').a.id),b2any=b2fx.kids.find(s=>s.t==='AnyState');
 // Full-body tricks and land use a final base-pose layer, then blend to the live selected pose.
 const full=layer('Play Full Body'),fullRest=state(full.l,timeline('_play_full_rest',1,{}),'play_full_rest');full.entry.kids.push(trans(fullRest.a.id,[],0));
 for(const [name,d]of Object.entries(durations)){
  const t=base('_reaction_rest'),e=copy(fxRestTracks);const k=(n,key,v)=>set(t,n,key,v),f=(n,key,v)=>set(e,n,key,v);
  const eyes=v=>{for(const side of ['left','right'])k('reaction_eye_'+side,17,v);};
  if(name==='petted'||name==='tickled'){const tick=name==='tickled';wave(t,'reaction_body',15,0,tick?.045:.025,d,tick?5:3);eyes([[0,1],[20,.15],[d-22,.15],[d,1]]);wave(t,'reaction_tail',15,0,.09,d,3);f('play_warm_sparks',18,[[0,0],[20,1],[d-25,.75],[d,0]]);if(tick){wave(t,'reaction_body',16,1,.025,d,5);wave(t,'reaction_head',15,0,.055,d,5);}}
  if(name==='eat'||name==='catchOrb'){const eat=name==='eat';f('play_food_spark',18,[[0,0],[10,1],[48,1],[62,0],[d,0]]);f('play_food_spark',13,[[0,230],[10,230],[32,120,1],[52,29,1],[d,29]]);f('play_food_spark',14,[[0,-40],[22,-70],[52,30,1],[d,30]]);for(const key of [16,17])f('play_food_spark',key,[[0,1],[44,1],[62,.1],[d,1]]);k('reaction_head',15,[[0,0],[30,-.06],[60,.04],[d,0]]);k('reaction_open_mouth',18,[[0,0],[38,1],[eat?95:62,1],[d-8,0],[d,0]]);k('reaction_smile',18,[[0,1],[38,0],[eat?95:62,0],[d-8,1],[d,1]]);k('reaction_open_mouth',17,eat?[[0,1],[40,1],[65,.35],[74,.8],[84,.35],[95,.8],[d,1]]:[[0,1],[45,1],[65,.3],[d,1]]);eyes([[0,1],[52,.45],[d-20,.45],[d,1]]);k('reaction_fin_right',15,[[0,0],[25,-.55],[55,-.55],[d,0]]);f('play_warm_sparks',18,[[0,0],[58,0],[70,.7],[d,0]]);}
  if(name==='bonk'||name==='dizzy'){const dizzy=name==='dizzy';wave(t,'reaction_head',15,0,dizzy?.10:.065,d,dizzy?3:2);wave(t,'reaction_body',15,0,dizzy?.035:.04,d,2);eyes([[0,1],[12,.5],[d-20,.5],[d,1]]);f('play_dizzy_stars',18,[[0,0],[12,1],[d-20,1],[d,0]]);wave(e,'play_dizzy_stars',16,1,.2,d,2);wave(e,'play_dizzy_stars',15,0,.12,d,2);if(!dizzy)k('reaction_body',13,[[0,0],[12,-16],[26,4],[d,0]]);}
  if(name==='levelUp'){eyes([[0,1],[35,.2],[95,.2],[130,1],[d,1]]);k('reaction_body',17,[[0,1],[38,1.06],[105,1.06],[d,1]]);k('reaction_head',15,[[0,0],[45,-.065],[110,-.065],[d,0]]);k('reaction_fin_left',15,[[0,0],[40,-.35],[105,-.35],[d,0]]);k('reaction_fin_right',15,[[0,0],[40,.35],[105,.35],[d,0]]);f('play_level_burst',18,[[0,0],[28,1],[85,.8],[140,0],[d,0]]);for(const key of [16,17])f('play_level_burst',key,[[0,.6],[65,1.18],[d,1]]);}
  if(name==='trickSpin'||name==='trickFlip'||name==='land'){
   const land=name==='land';const ft={...(land?copy(sit):base('idle')),...copy(activityClear),...(land?copy(sitOn):copy(sitNeutral)),lounging_scale:{16:1,17:1}};
   for(const [n,props]of Object.entries(ft))for(const [key,value]of Object.entries(props))if(Array.isArray(value))props[key]=value[0][1];
   if(land){ft.float_control={13:700,14:[[0,600],[16,600],[32,1025,1],[48,1025]],15:0,18:1};ft.held_drag_constraint={172:0};ft.body[17]=[[0,1.25],[32,1.02],[40,1.28],[48,1.25]];ft.head[14]=[[0,-77],[32,-58],[40,-82],[48,-77]];Object.assign(ft,base('_usage_orbit_depart'));}
   else {ft.float_control={13:560,14:500,15:0,18:1};f('play_trick',16,[[0,1],[16,.55,1],[70,.55],[90,1,1]]);f('play_trick',17,[[0,1],[16,.55,1],[70,.55],[90,1,1]]);if(name==='trickFlip')f('play_trick',15,[[0,0],[16,0],[70,Math.PI*2,1],[90,Math.PI*2]]);else{f('play_trick',13,[[0,0],[16,0],[30,80],[44,0],[58,-80],[72,0],[90,0]]);f('play_trick',14,[[0,0],[16,0],[30,-70],[44,-140],[58,-70],[72,0],[90,0]]);f('play_trick',15,[[0,0],[16,0],[70,Math.PI*2,1],[90,Math.PI*2]]);}f('play_warm_sparks',18,[[0,0],[20,.6],[68,.6],[90,0]]);}
   const fs=state(full.l,timeline('_full_'+name,d,ft),'full_'+name);full.any.kids.push(trans(fs.a.id,[cond(name,'Trigger',0)],180));fs.kids.push(end(fullRest.a.id,400));
  }else full.any.kids.push(trans(fullRest.a.id,[cond(name,'Trigger',0)],180));
  const bs=state(fidgets,timeline(name,d,t),'reaction_'+name);fidgetAny.kids.push(trans(bs.a.id,[cond(name,'Trigger',0)],180));bs.kids.push(end(bodyRest.a.id));
  const es=state(fx.l,timeline('_play_fx_'+name,d,e),'fx_'+name);fx.any.kids.push(trans(es.a.id,[cond(name,'Trigger',0)],180));es.kids.push(end(fxRest.a.id,name==='trickSpin'||name==='trickFlip'?0:180));b2any.kids.push(trans(b2rest.a.id,[cond(name,'Trigger',0)],180));
 }
 const oldTriggers=['lookAround','stretch','yawn','orbPlay','tailChase','scratchEar','sneeze','perkUp','alertRing','approve','taskDone','error','usageReset','limitHit','greet','goodbye'];for(const n of oldTriggers){fx.any.kids.push(trans(fxRest.a.id,[cond(n,'Trigger',0)],180));full.any.kids.push(trans(fullRest.a.id,[cond(n,'Trigger',0)],180));}
 require('fs').writeFileSync('work/batch3-meta.json',JSON.stringify({durations},null,2));
};


