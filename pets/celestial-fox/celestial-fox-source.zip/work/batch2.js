module.exports=({root,ab,vm,machine,master,rig,el,id,group,vector,ellipse,glow,grad})=>{
 const find=(name,e=root)=>{if(e.a.name===name)return e;for(const c of e.kids){const f=find(name,c);if(f)return f;}};
 const copy=e=>JSON.parse(JSON.stringify(e));
 const props=vm.kids.find(e=>e.t==='ViewModelInstance');
 const durations={alertRing:72,approve:72,taskDone:150,error:90,usageReset:150,limitHit:120,greet:120,goodbye:90};
 for(const name of Object.keys(durations)){vm.kids.push(el('ViewModelPropertyTrigger',{name,id:id('property_'+name)}));props.kids.push(el('ViewModelInstanceTrigger',{viewModelPropertyId:id('property_'+name),propertyValue:0}));}
 const path=n=>'0:3-'+(n==='state'?'0:5':id('property_'+n));
 const bind=(e,n,key,converter)=>e.kids.push(el('DataBindContext',{sourcePathIds:path(n),propertyKey:key,...(converter?{converterId:id(converter)}:{})}));
 const cond=(n,t,v,op='equal')=>el('TransitionViewModelCondition',{opValue:op},[el('TransitionPropertyViewModelComparator',{},[el('BindableProperty'+t,{},[el('DataBindContext',{sourcePathIds:path(n),propertyKey:t==='Trigger'?686:636})])]),el('TransitionValue'+t+'Comparator',{value:v})]);
 const trans=(to,conditions=[],duration=240,extra={})=>el('StateTransition',{stateToId:to,duration,enableEarlyExit:true,...extra},conditions);
 const end=(to,ms=180)=>trans(to,[],ms,{enableExitTime:true,exitTimeIsPercetange:true,exitTime:100});
 function timeline(name,duration,tracks,loopValue='oneShot'){const a=el('LinearAnimation',{name,id:id('animation_'+name),fps:60,duration,loopValue});ab.kids.push(a);for(const [name,values]of Object.entries(tracks)){const o=el('KeyedObject',{objectId:find(name)?.a.id??id(name)});a.kids.push(o);for(const [key,val]of Object.entries(values)){const p=el('KeyedProperty',{propertyKey:key});o.kids.push(p);for(const [frame,value,ease]of typeof val==='number'?[[0,val]]:val){const k=el('KeyFrameDouble',{frame,value,interpolationType:ease?'cubic':'linear'});if(ease)k.kids.push(el('CubicEaseInterpolator',{x1:.25,y1:.1,x2:.25,y2:1}));p.kids.push(k);}}}return a;}
 function state(layer,animation,name,x=240,y=0){const s=el('AnimationState',{id:id('state_'+name),animationId:animation.a.id,reset:true,x,y});layer.kids.push(s);return s;}
 function layer(name){const l=el('StateMachineLayer',{name,id:id('layer_'+name)}),any=el('AnyState'),entry=el('EntryState');machine.kids.push(l);l.kids.push(any,el('ExitState'),entry);return {l,any,entry};}
 function baseTracks(anim){const tracks={};for(const o of find(anim).kids){if(o.t!=='KeyedObject')continue;const target=[...walk(root)].find(e=>e.a.id===o.a.objectId);tracks[target.a.name]={};for(const p of o.kids)tracks[target.a.name][p.a.propertyKey]=Number(p.kids[0].a.value);}return tracks;}
 function* walk(e){yield e;for(const c of e.kids)yield*walk(c);}
 function wrap(parent,child,name,attrs={}){const w=el('Node',{name,id:id(name),exportName:true,...attrs},[child]);parent.kids[parent.kids.indexOf(child)]=w;return w;}
 const rx=find('reaction_body'),head=find('head');
 // Formulas must recognize only state 8 as grounded; new states use floating anchors.
 const V=v=>el('FormulaTokenValue',{operationValue:v}),I=()=>el('FormulaTokenInput'),O=o=>el('FormulaTokenOperation',{operationType:o}),C=()=>el('FormulaTokenParenthesisClose'),A=()=>el('FormulaTokenArgumentSeparator');
 const fn=(f,...args)=>[el('FormulaTokenFunction',{functionType:f}),...args.flatMap((a,i)=>[...(i?[A()]:[]),...(Array.isArray(a)?a:[a])]),C()];
 const src=n=>{const v=V(0);bind(v,n,777);return v;};
 const grounded=()=>[...fn('max',V(0),[V(1),O('subtract'),...fn('max',[src('state'),O('subtract'),V(8)],[V(8),O('subtract'),src('state')])])];
 find('stats_target_y').kids=[V(130),O('add'),V(640),O('multiply'),...grounded(),O('add'),I(),O('multiply'),el('FormulaTokenParenthesisOpen'),V(1070),O('subtract'),V(640),O('multiply'),...grounded(),C()];
 find('stats_target_x').kids=[V(560),O('add'),...grounded(),O('multiply'),el('FormulaTokenParenthesisOpen'),V(60),O('subtract'),V(420),O('multiply'),I(),C()];
 const route=el('DataConverterFormula',{name:'stats_weekly_route_exact',id:id('stats_weekly_route_exact')},[V(1020),O('subtract'),V(920),O('multiply'),...grounded()]);root.kids.push(route);
 for(const n of ['weekly_side_anchor','weekly_travel_anchor'])find(n).kids.filter(e=>e.t==='DataBindContext'&&Number(e.a.propertyKey)===13).forEach(e=>e.a.converterId=route.a.id);
 // New vector accents are reset by a separate context layer when returning to states 0–8.
 const pad=group('busy_workpad',[590,730],rx,[560,600],{opacity:0,exportName:true});
 vector(pad,'busy glass pad','M 491 711 L 663 711 C 675 711 689 736 680 743 L 510 743 C 499 743 483 718 491 711 Z','99223853','CDB9E9FF',2.2);
 for(let i=0;i<4;i++)ellipse(pad,'busy key '+i,522+i*36,727,10,3,'BCE3F6FF');
 const pulse=group('busy_key_pulse',[522,727],pad,[590,730],{opacity:0,exportName:true});glow(pulse,'busy pulse',522,727,22,'B5EDFF','55');ellipse(pulse,'busy active key',522,727,10,3,'FFFFFFFF');
 const puzzled=group('confused_motes',[866,445],rx,[560,600],{opacity:0,exportName:true});
 glow(puzzled,'question halo',877,445,45,'D8CEFF','33');
 vector(puzzled,'question curve','M 860 428 C 864 409 896 408 897 428 C 898 445 877 443 878 457',null,'FFF2DAAC',5);ellipse(puzzled,'question dot',878,470,3,3,'FFFFE6BC');
 vector(puzzled,'puzzled swirl','M 848 484 C 861 491 887 490 901 482 C 915 474 903 468 897 473',null,'99B7D9FF',2);
 const signal=group('disconnected_signal',[958,486],rx,[560,600],{opacity:0,exportName:true});
 ellipse(signal,'offline bubble',958,486,41,41,'58283B55','AA9DABBB',2);
 vector(signal,'broken link upper','M 946 481 L 955 472 C 969 458 982 472 970 484 L 965 489',null,'FFD4DCE3',5);
 vector(signal,'broken link lower','M 950 488 L 946 492 C 934 507 950 517 961 505 L 966 499',null,'FFD4DCE3',5);
 vector(signal,'connection break','M 940 468 L 938 462 M 974 505 L 980 509',null,'FFFFDBA6',2.5);
 for(const side of ['left','right'])wrap(find('gaze_eye_'+side),find('reaction_eye_'+side),'activity_eye_'+side);
 const contextRest={busy_workpad:{18:0},busy_key_pulse:{18:0,13:-68,14:-3},confused_motes:{18:0,15:0},disconnected_signal:{18:0,15:0},activity_eye_left:{13:0,14:0},activity_eye_right:{13:0,14:0}};
 const cx=layer('Activity Context'),cr=state(cx.l,timeline('_activity_clear',1,contextRest),'activity_clear'),cl=state(cx.l,timeline('_activity_live',1,{}),'activity_live',480);cx.entry.kids.push(trans(cr.a.id,[],0));cr.kids.push(trans(cl.a.id,[cond('state','Number',9,'greaterThanOrEqual')],180));cl.kids.push(trans(cr.a.id,[cond('state','Number',9,'lessThan')],180));
 const loopNames=['working_busy','confused','disconnected'],loopFrames=[150,180,240];
 const petLayer=find('Pet States'),existing=petLayer.kids.filter(e=>e.t==='AnimationState'),newStates=[];
 for(let index=0;index<3;index++){const n=loopNames[index],d=loopFrames[index],t={...baseTracks('idle'),...copy(contextRest)};
 const set=(name,key,frames)=>t[name][key]=frames;
 const wave=(name,key,base,amp,cycles=1,phase=0)=>set(name,key,Array.from({length:21},(_,i)=>[Math.round(i*d/20),base+amp*Math.sin(i*Math.PI*2/20*cycles+phase)]));
 wave('float_control',14,600,5);wave('head',15,index===0?-.08:0,index===0?.025:.10);wave('tail_bone_0',15,Math.PI/2,.025);wave('tail_bone_1',15,0,.045,1,1);wave('tail_bone_2',15,0,.06,1,2);wave('body',17,1,.012,2);
 if(index===0){t.busy_workpad[18]=1;t.busy_key_pulse[18]=.9;wave('busy_key_pulse',13,-14,54,4);wave('busy_key_pulse',18,.55,.4,5);wave('fin_left',15,-2.3,.17,5);wave('fin_right',15,.85,.23,5,Math.PI);t.brow_left[15]=-.12;t.brow_right[15]=.08;set('eye_left',17,[[0,1],[104,1],[109,.08],[114,1],[150,1]]);set('eye_right',17,[[0,1],[105,1],[110,.08],[115,1],[150,1]]);}
 if(index===1){t.confused_motes[18]=1;wave('confused_motes',15,0,.09);wave('ear_left',15,-.09,.055);wave('ear_right',15,.14,.05);t.brow_left[15]=-.25;t.brow_right[15]=-.15;t.eye_left[17]=.85;t.eye_right[17]=1;for(const side of ['left','right'])wave('activity_eye_'+side,13,0,7);}
 if(index===2){t.disconnected_signal[18]=1;wave('disconnected_signal',18,.65,.22);t.ear_left[15]=-.10;t.ear_right[15]=.12;t.brow_left[15]=-.20;t.brow_right[15]=.16;for(const side of ['left','right'])set('activity_eye_'+side,13,[[0,0],[45,-8,1],[100,-8],[145,8,1],[195,8],[240,0,1]]);}
 const s=state(petLayer,timeline(n,d,t,'loop'),n,240+index*240,650);newStates.push(s);
 }
 existing.forEach(s=>newStates.forEach((to,i)=>s.kids.push(trans(to.a.id,[cond('state','Number',9+i)],s.a.id===id('state_lounging')?360:240))));
 const settling=existing.find(s=>s.a.id===id('state_lounging_settle'));
 newStates.forEach((s,i)=>{for(let j=0;j<8;j++)s.kids.push(trans(id('state_'+['idle','sleeping','working_thinking','needs_attention','done_happy','idea','low_usage_worry','limit_reached'][j]),[cond('state','Number',j)],j===1||j===7?320:240));s.kids.push(trans(settling.a.id,[cond('state','Number',8)],180));newStates.forEach((to,j)=>{if(i!==j)s.kids.push(trans(to.a.id,[cond('state','Number',9+j)],240));});});
 // Shorter horizontal orbit for the searching/disconnected state, still below the eyes.
 const orbitLayer=find('Usage Orbit'),normal=orbitLayer.kids.find(s=>s.a.id===id('usage_orbit_state')),lounger=orbitLayer.kids.find(s=>s.a.id===id('state_usage_orbit_lounging'));
 const disconnectTracks={};for(const [i,n]of ['session','weekly','fable'].entries()){disconnectTracks[n+'_meter']={13:[],14:[]};for(let f=0;f<=1440;f+=24){const th=-2.45+i*Math.PI*2/3+f*Math.PI*2/1440;disconnectTracks[n+'_meter'][13].push([f,240*Math.cos(th)]);disconnectTracks[n+'_meter'][14].push([f,96*Math.sin(th)]);}}
 const disconnectOrbit=state(orbitLayer,timeline('_usage_orbit_disconnected',1440,disconnectTracks,'loop'),'usage_orbit_disconnected',960);
 normal.kids.push(trans(disconnectOrbit.a.id,[cond('state','Number',11)],360));disconnectOrbit.kids.push(trans(lounger.a.id,[cond('state','Number',8)],360),trans(normal.a.id,[cond('state','Number',11,'notEqual')],360));
 // Event paint effects are chained after the live usage trim: resetting multiplies the
 // current arc length without changing any application-owned usage or color value.
 const fxNeutral={},meterModeOff={},meterModeOn={};
 function channel(t,n,k,v){t[n]??={};t[n][k]=v;}
 const meters=['session','weekly','fable'];
 for(const [i,n]of meters.entries()){
  const visual=find(n+'_stats_visual'),calm=find(n+'_calm'),aura=find(n+' aura');
  const colored=el('Node',{name:n+'_live_colors',id:id(n+'_live_colors'),exportName:true,opacity:1},[calm]);visual.kids[visual.kids.indexOf(calm)]=colored;channel(meterModeOff,aura.a.name,18,.16);channel(meterModeOn,aura.a.name,18,0);
  const grey=group(n+'_offline_colors',[0,0],visual,[0,0],{opacity:0,exportName:true});
  // Paint grey behind white marks, and above the neutral blue shell.
  visual.kids.splice(visual.kids.indexOf(grey),1);const dots=visual.kids.findIndex(e=>e.a.name===n+' identity dot 1');visual.kids.splice(dots,0,grey);
  ellipse(grey,n+' grey cloud',0,0,30,30,grad('RadialGradient',[-8,-10,30,0],[[0,'D6A4AFBA'],[.7,'BC637280'],[1,'BB8695A2']]));
  let firstGroup;
  for(const [j,shape]of [find(n+' calm ring'),find(n+' color ring glow')].entries()){
   const stroke=shape.kids.find(e=>e.t==='Stroke'),trim=stroke.kids.find(e=>e.t==='TrimPath');stroke.kids=stroke.kids.filter(e=>e!==trim);
   const resetName=n+'_reset_trim_'+j,reset=el('TrimPath',{name:resetName,id:id(resetName),start:0,end:1,modeValue:'sequential'});
   const effects=el('GroupEffect',{name:n+'_usage_effect_'+j,id:id(n+'_usage_effect_'+j)},[trim,reset]);ab.kids.push(effects);stroke.kids.push(el('TargetEffect',{targetId:effects.a.id}));channel(fxNeutral,resetName,115,1);if(!firstGroup)firstGroup=effects;
  }
  const geometry=copy(find(n+' calm ring').kids.find(e=>e.t==='PointsPath'));geometry.a.name=n+' offline ring path';
  grey.kids.push(el('Shape',{name:n+' offline ring',id:id(n+'_offline_ring')},[geometry,el('Stroke',{thickness:7,cap:'butt'},[el('SolidColor',{colorValue:'FFD4DCE3'}),el('TargetEffect',{targetId:firstGroup.a.id})])]));
  // Most-used orb receives the limit-hit remainder; ties prefer session, then weekly.
  const ceilPositive=arr=>fn('ceil',fn('min',V(1),fn('max',V(0),arr)));
  const factors=meters.filter(m=>m!==n).map(m=>{const other=meters.indexOf(m);return other<i?ceilPositive([src(n),O('subtract'),src(m)]):[V(1),O('subtract'),...ceilPositive([src(m),O('subtract'),src(n)])];});
  const winnerName=n+'_limit_winner',winner=el('DataConverterFormula',{name:winnerName,id:id(winnerName)},[el('FormulaTokenParenthesisOpen'),...factors[0],C(),O('multiply'),el('FormulaTokenParenthesisOpen'),...factors[1],C()]);root.kids.push(winner);
  const remaining=el('TrimPath',{name:n+'_remaining_usage',id:id(n+'_remaining_usage'),start:0,end:1,modeValue:'sequential'});bind(remaining,n,114,'usage_fraction');
  const limitTrim=el('TrimPath',{name:n+'_limit_trim',id:id(n+'_limit_trim'),start:0,end:0,modeValue:'sequential'}),limitEffect=el('GroupEffect',{name:n+'_limit_effect',id:id(n+'_limit_effect')},[remaining,limitTrim]);ab.kids.push(limitEffect);channel(fxNeutral,limitTrim.a.name,115,0);
  for(const [label,parent,color]of [['live',colored,null],['offline',grey,'FFD4DCE3']]){
   const win=group(n+'_limit_'+label+'_winner',[0,0],parent,[0,0],{opacity:0});bind(win,n,18,winnerName);
   const rem=group(n+'_limit_'+label,[0,0],win,[0,0],{opacity:0,exportName:true});channel(fxNeutral,rem.a.name,18,0);
   const solid=el('SolidColor',{colorValue:color||'FFB7E7FF'});if(!color)bind(solid,n+'Color',37);
   const geom=copy(geometry);geom.a.name=n+' '+label+' remainder path';rem.kids.push(el('Shape',{name:n+' '+label+' remainder',id:id(n+'_'+label+'_remainder')},[geom,el('Stroke',{thickness:7,cap:'butt'},[solid,el('TargetEffect',{targetId:limitEffect.a.id})])]));
  }
  const sparks=group(n+'_reset_sparks',[0,0],visual,[0,0],{opacity:0,exportName:true});for(const [j,[x,y]]of [[-36,-20],[35,-22],[-32,25],[34,24]].entries()){vector(sparks,n+' reset star '+j,`M ${x-2} ${y} L ${x+2} ${y} M ${x} ${y-3} L ${x} ${y+3}`,null,'FFF3F7FF',1.2);}channel(fxNeutral,sparks.a.name,18,0);channel(fxNeutral,sparks.a.name,16,1);channel(fxNeutral,sparks.a.name,17,1);
  const flash=group(n+'_event_flash',[0,0],visual,[0,0],{opacity:0,exportName:true});ellipse(flash,n+' event flash ring',0,0,27,27,null,'FFE9F8FF',7);channel(fxNeutral,flash.a.name,18,0);
  channel(meterModeOff,colored.a.name,18,1);channel(meterModeOn,colored.a.name,18,0);channel(meterModeOff,grey.a.name,18,0);channel(meterModeOn,grey.a.name,18,1);
 }
 const mm=layer('Meter Connection'),m0=state(mm.l,timeline('_meter_connected',1,meterModeOff),'meter_connected'),m1=state(mm.l,timeline('_meter_disconnected',1,meterModeOn),'meter_disconnected',480);mm.entry.kids.push(trans(m0.a.id,[],0));m0.kids.push(trans(m1.a.id,[cond('state','Number',11)],300));m1.kids.push(trans(m0.a.id,[cond('state','Number',11,'notEqual')],300));
 // Clone status symbols for reactions, preserving the originals' state-owned opacity tracks.
 function cloneBadge(old,name){const cloned=copy(find(old));const ren=e=>{if(e.a.id)e.a.id=id(name+'_'+e.a.id);if(e.a.name)e.a.name=name+' '+e.a.name;e.kids.forEach(ren);};ren(cloned);cloned.a.name=name;cloned.a.id=id(name);cloned.a.opacity=0;cloned.a.exportName=true;rx.kids.push(cloned);return cloned;}
 const eventBell=cloneBadge('bell_badge','event_bell'),eventCheck=cloneBadge('check_badge','event_check');
 const bellSwing=[...walk(eventBell)].find(e=>e.a.name==='event_bell bell_swing');bellSwing.a.exportName=true;
 for(const badge of [eventBell,eventCheck]){channel(fxNeutral,badge.a.name,18,0);channel(fxNeutral,badge.a.name,16,1);channel(fxNeutral,badge.a.name,17,1);}channel(fxNeutral,bellSwing.a.name,15,0);
 const errorMotes=group('event_error_motes',[742,466],head,[604,523],{opacity:0,exportName:true});vector(errorMotes,'oops lightning','M 723 451 L 733 438 L 742 450 L 752 437',null,'FFFFC4A7',3);ellipse(errorMotes,'oops pearl',749,466,3.5,3.5,'FFFFD8B7');channel(fxNeutral,errorMotes.a.name,18,0);
 // Wave beside the head in both floating and grounded poses; zero-strength at rest.
 const waveAnchor=group('event_wave_anchor',[750,445],head,[604,523],{rotation:-.6,exportName:true});
 channel(fxNeutral,waveAnchor.a.name,15,-.6);
 for(const type of ['TranslationConstraint','RotationConstraint']){const n='event_wave_'+type;find('fin_right').kids.push(el(type,{name:n,id:id(n),targetId:waveAnchor.a.id,strength:0}));channel(fxNeutral,n,172,0);}
 const fx=layer('Activity Reactions'),fxRest=state(fx.l,timeline('_activity_fx_rest',1,fxNeutral),'activity_fx_rest');fx.entry.kids.push(trans(fxRest.a.id,[],0));
 const bodyLayer=find('Fidgets'),bodyAny=bodyLayer.kids.find(e=>e.t==='AnyState'),bodyRest=bodyLayer.kids.find(e=>e.a.id===id('state_reaction_rest'));
 for(const [name,d]of Object.entries(durations)){const t=baseTracks('_reaction_rest'),e=copy(fxNeutral),set=(n,k,v)=>t[n][k]=v,eff=(n,k,v)=>e[n][k]=v;
  if(name==='alertRing'){set('reaction_body',14,[[0,0],[10,-16],[22,3],[42,-3],[d,0,1]]);set('reaction_body',17,[[0,1],[10,1.045],[22,.98],[d,1,1]]);set('reaction_ear_left',15,[[0,0],[12,.06],[d,0,1]]);set('reaction_ear_right',15,[[0,0],[12,-.06],[d,0,1]]);eff('event_bell',18,[[0,0],[8,1],[50,1],[72,0]]);eff(bellSwing.a.name,15,[[0,0],[8,.4],[16,-.4],[24,.32],[32,-.25],[40,.15],[50,0],[72,0]]);}
  if(name==='approve'){set('reaction_head',15,[[0,0],[18,.10,1],[36,-.035,1],[54,.035],[d,0,1]]);for(const side of ['left','right'])set('reaction_eye_'+side,17,[[0,1],[20,.55],[36,.55],[60,1],[d,1]]);}
  if(name==='taskDone'){set('reaction_body',14,[[0,0],[22,-25,1],[40,1],[58,-14],[90,0,1],[d,0]]);set('reaction_body',17,[[0,1],[22,1.055],[40,.97],[65,1],[d,1]]);for(const side of ['left','right'])set('reaction_eye_'+side,17,[[0,1],[18,.20],[68,.20],[94,1],[d,1]]);eff('event_check',18,[[0,0],[12,1],[120,1],[150,0]]);for(const k of [16,17])eff('event_check',k,[[0,.7],[22,1.12],[38,1],[150,1]]);set('reaction_sparks',18,[[0,0],[22,1],[65,0],[150,0]]);}
  if(name==='error'){set('reaction_body',15,[[0,0],[12,-.065],[22,.045],[38,-.02],[d,0,1]]);set('reaction_body',17,[[0,1],[14,.94],[34,1.01],[d,1]]);for(const side of ['left','right'])set('reaction_eye_'+side,17,[[0,1],[12,.06],[27,.06],[48,1],[d,1]]);eff('event_error_motes',18,[[0,0],[12,1],[50,.8],[75,0],[d,0]]);}
  if(name==='usageReset'){set('reaction_body',17,[[0,1],[40,1.085,1],[85,1.085],[120,1,1],[d,1]]);set('reaction_fin_left',15,[[0,0],[45,-.45,1],[90,-.45],[d,0,1]]);set('reaction_fin_right',15,[[0,0],[45,.35,1],[90,.35],[d,0,1]]);for(const n of meters){for(const j of [0,1])eff(n+'_reset_trim_'+j,115,[[0,1],[35,0,1],[50,0],[120,1,1],[d,1]]);eff(n+'_event_flash',18,[[0,0],[35,0],[43,.8],[52,0],[d,0]]);eff(n+'_reset_sparks',18,[[0,0],[36,0],[44,1],[92,0],[d,0]]);for(const k of [16,17])eff(n+'_reset_sparks',k,[[0,.8],[36,.8],[90,1.25],[d,1]]);}}
  if(name==='limitHit'){set('reaction_body',17,[[0,1],[50,.925,1],[90,.925],[d,1,1]]);set('reaction_body',14,[[0,0],[55,12,1],[90,12],[d,0,1]]);set('reaction_head',15,[[0,0],[45,.045,1],[95,.045],[d,0,1]]);for(const side of ['left','right'])set('reaction_eye_'+side,17,[[0,1],[45,.3,1],[90,.3],[d,1,1]]);for(const n of meters){eff(n+'_limit_trim',115,[[0,0],[65,1,1],[100,1],[d,0]]);for(const label of ['live','offline'])eff(n+'_limit_'+label,18,[[0,0],[10,1],[100,1],[d,0]]);}}
  if(name==='greet'||name==='goodbye'){const full=name==='greet';set('scratch_hand',13,[[0,0],[24,full?180:140,1],[d-22,full?180:140],[d,0,1]]);set('scratch_hand',14,[[0,0],[24,full?-20:10,1],[d-22,full?-20:10],[d,0,1]]);set('reaction_fin_right',15,[[0,0],[22,-.65,1],[32,-.40],[42,-.72],[52,-.40],[62,-.70],[d-20,-.4],[d,0,1]]);set('reaction_head',15,[[0,0],[30,full?-.035:.045,1],[d-20,full?-.035:.045],[d,0,1]]);}
  if(name==='greet'||name==='goodbye'){for(const type of ['TranslationConstraint','RotationConstraint'])eff('event_wave_'+type,172,[[0,0],[24,1,1],[d-22,1],[d,0,1]]);eff('event_wave_anchor',15,[[0,-.6],[24,-.6],[32,-.4],[42,-.8],[52,-.4],[62,-.8],[d,-.6]]);}
  const body=state(bodyLayer,timeline(name,d,t),'reaction_'+name,240+Object.keys(durations).indexOf(name)%4*240,700+Math.floor(Object.keys(durations).indexOf(name)/4)*180);bodyAny.kids.push(trans(body.a.id,[cond(name,'Trigger',0)],180));body.kids.push(end(bodyRest.a.id));
  const effect=state(fx.l,timeline('_fx_'+name,d,e),'fx_'+name,480+Object.keys(durations).indexOf(name)*180);fx.any.kids.push(trans(effect.a.id,[cond(name,'Trigger',0)],180));effect.kids.push(end(fxRest.a.id));
 }
 for(const n of ['lookAround','stretch','yawn','orbPlay','tailChase','scratchEar','sneeze','perkUp'])fx.any.kids.push(trans(fxRest.a.id,[cond(n,'Trigger',0)],180));
 require('fs').writeFileSync('work/batch2-meta.json',JSON.stringify({durations,loopNames,loopFrames},null,2));
};

