# Celestial Fox — revision 4, Batches 1–3 source

This is the complete editable RML vector, rig, animation, data-binding, and state-machine source.

Build with Rive CLI 1.0.3 or a compatible newer version:

    rive . --verify
    rive . --once

Output: build/celestial-fox.riv

The project is standalone and has no external assets, scripts, fonts, images, or audio.
No account credentials are required to compile this pure-RML project.
The runtime target tested is @rive-app/webgl2 2.42.1 with autoBind enabled.
An editor .rev file is not part of this source package.

See state-map.md for all states, triggers, defaults, integration, anchors, bounds and caveats.
The verification folder records runtime behavior and preservation of the prior version.
Only Batches 1–3 are implemented. Later batches must preserve this public interface and existing IDs.
