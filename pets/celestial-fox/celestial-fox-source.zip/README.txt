Celestial Fox — Batch 6 source

Compile from this directory with Rive CLI 1.0.3:
  rive . --once

The output is build/celestial-fox.riv. See state-map.md for the complete interface.
One artboard, one state machine, 54 view-model properties, states 0–15 unchanged.
No images, fonts, audio, scripts or external assets are embedded in the Rive.

Optional build-time JavaScript generators are included under work/. Run from the
archive root: node work/build-pet.js, then rive work/pet --once. Modules apply in
batch order. Preserve their order and the stable ID allocator when revising.
The generators require Node.js and no npm dependencies.

Contact sheets show all 16 states plus held at both facing directions, ambient 0.
The 12-second ambient GIFs show earLeft, earRight, tailSway, then all three, at
growth 3; each segment sweeps through -1 and 1 and returns to zero. Dark/white
views are side by side. The clip replay resets its shorter-than-orbit phase.

See verification/ for checks made in the actual @rive-app/webgl2 2.42.1 runtime.
