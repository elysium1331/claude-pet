Celestial Fox — Batch 5 source

Compile the editable RML project from this directory with Rive CLI 1.0.3:
  rive . --once

The result is build/celestial-fox.riv. See state-map.md for the complete interface.
No images, fonts, audio, scripts or external assets are embedded.

The optional JavaScript generators are included under work/. From this archive's
root, run `node work/build-pet.js`, then `rive work/pet --once` to regenerate and
compile the same project. Modules are applied in batch order; preserve this order
and the stable ID allocator when making revisions. The generators require Node.js
but no npm dependencies. JavaScript is build-time only, never embedded in the Rive.

Contact sheets and GIFs were rendered with @rive-app/webgl2 2.42.1. GIF comparisons
show dark and white backgrounds side by side. Walking shows two 1.2-second loops;
floating travel shows one 2-second loop; orbit shows its complete 24-second cycle.
The turn clips show both directions. The looping GIF replay may reset orbit phase
in clips shorter than a full orbit; the production orbit itself remains seamless.
